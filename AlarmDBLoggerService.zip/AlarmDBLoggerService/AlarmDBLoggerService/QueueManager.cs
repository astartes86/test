﻿using System;
using System.Collections.Generic;
using OPC;

namespace AlarmDBLoggerService
{
   public static class QueueManager
    {
        public static List<Queue<ActiveMessage>> QueueSqlMessList = new List<Queue<ActiveMessage>>();
        public static List<Queue<OpcTag>> QueueOpcDataList = new List<Queue<OpcTag>>();
        public static List<Queue<OpcTags>> QueueOpcGroupDataList = new List<Queue<OpcTags>>();
        public static Queue<LogMessage> QueueLog = new Queue<LogMessage>(1000);

        public static void CreateQueueSqlMess()
       {
            Queue<ActiveMessage> queueSqlMessages = new Queue<ActiveMessage>(1000);
            QueueSqlMessList.Add(queueSqlMessages);
       }

        public static void CreateQueueOpcData()
        {
            Queue<OpcTag> queueOpc = new Queue<OpcTag>(1000);
            QueueOpcDataList.Add(queueOpc);
        }

        public static void CreateQueueOpcGrupData()
        {
            Queue<OpcTags> queueOpcGroup = new Queue<OpcTags>(1000);
            QueueOpcGroupDataList.Add(queueOpcGroup);
        }
    }

    public class ActiveMessage : ICloneable
    {
        public string Text;
        public int SysId;
        public int SysNum;
        public int MessNum;
        public string MessValue;
        public Device Device;
        public string Variable;
        public OpcTags OpcTags;

        public ActiveMessage(string text, int sysId, int sysNum, int messNum, string messValue, Device device, string variable="", OpcTags opcTags = null)
        {
            Text = text;
            SysId = sysId;
            SysNum = sysNum;
            MessNum = messNum;
            MessValue = messValue;
            Device = device;
            Variable = variable;
            OpcTags = opcTags;
        }

        public ActiveMessage(string[] mess, Device device)
        {
            Text = mess[0];
            //Text = Text.Replace("@", device.GetProperty(Constants.Name));
            SysId = Convert.ToInt32(mess[3]);
            SysNum = Convert.ToInt32(mess[4]);
            MessNum = Convert.ToInt32(mess[5]);
            MessValue = mess[6];
            Device = device;
            Variable = "";
            OpcTags = null;
        }
        private ActiveMessage()
        {
            
        }

        public object Clone()
        {
            return new ActiveMessage
            {
            Text = Text,
            SysId = SysId,
            SysNum = SysNum,
            MessNum = MessNum,
            MessValue = MessValue,
            Device = Device,
            Variable = Variable,
            OpcTags = OpcTags,
            };
        }
    }

    public class OpcTag
    {
        public string TagPath;
        public object TagValue;

        public OpcTag(string tagPath, object tagValue)
        {
            TagPath = tagPath;
            TagValue = tagValue;
        }
    }

    public class OpcTags
    {
        public string[] TagPath;
        public object[] TagValue;
        public string[] DataTypes;

        public OpcTags(string[] tagPath, object[] tagValue, string[] dataTypes)
        {
            TagPath = tagPath;
            TagValue = tagValue;
            DataTypes = dataTypes;
        }
    }

    public class LogMessage
    {
        public string Message;
        public DateTime DateTime;

        public LogMessage(string message, DateTime dateTime)
        {
            Message = message;
            DateTime = dateTime;
        }
    }
}
