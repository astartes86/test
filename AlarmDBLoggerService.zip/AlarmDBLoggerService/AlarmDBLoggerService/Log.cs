﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Remoting.Contexts;

namespace AlarmDBLoggerService
{

    public static class Log
    {

        public static bool StopLog;
        static string LogFilePath { get; set; } = @"C:\Active\Logs\AlarmDBLoggerService_LogFile_" +
                                                 DateTime.Now.ToString("yyyy-M-d") + ".Log";

        static Log()
        {
            try
            {
                StreamWriter file = new StreamWriter(LogFilePath, true);
                file.WriteLine();
                file.Close();
            }
            catch (Exception)
            {
                //
            }
        }

        public static void WriteLogToFile(Exception exception)
        {
            try
            {
                //if (StopLog) return;
                //if (exception.InnerException != null)
                //{
                //    WriteLogToFile(exception);
                //}
                //bool append = true;
                //FileInfo fileInfo = new FileInfo(LogFilePath);
                //if (fileInfo.Length > 52428800) append = false;
                //StreamWriter file = new StreamWriter(LogFilePath, append);
                //file.WriteLine("[" + DateTime.Now + "] " + ":" + exception.Message + ":" +
                //               exception.Source + ":" + exception.TargetSite + ":" + exception.StackTrace);
                //file.Close();
                QueueManager.QueueLog.Enqueue(new LogMessage(exception.Message + ":" + exception.Source + ":" + exception.TargetSite + ":" + exception.StackTrace, DateTime.Now));
            }
            catch (Exception)
            {
                //
            }
        }

        public static void WriteLogToFile(string message)
        {
            try
            {
                //if (StopLog) return;
                //bool append = true;
                //FileInfo fileInfo = new FileInfo(LogFilePath);
                //if (fileInfo.Length > 52428800) append = false;
                //StreamWriter file = new StreamWriter(LogFilePath, append);
                //file.WriteLine("[" + DateTime.Now + "] " + message);
                //file.Close();
                QueueManager.QueueLog.Enqueue(new LogMessage(message, DateTime.Now));
            }
            catch (Exception)
            {
                //
            }
        }

        public static void WriteLogToFile(LogMessage message)
        {
            try
            {
                if (StopLog) return;
                bool append = true;
                if (File.Exists(LogFilePath))
                {
                    FileInfo fileInfo = new FileInfo(LogFilePath);
                    if (fileInfo.Length > 52428800) append = false;
                }
                StreamWriter file = new StreamWriter(LogFilePath, append);
                file.WriteLine("[" + message.DateTime + "] " + message.Message);
                file.Close();
            }
            catch (Exception)
            {
                //
            }
        }
    }
}
