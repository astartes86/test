using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;

namespace AlarmDBLoggerService
{
    public class NativeMethods
    {
        [DllImport("kernel32", CharSet = CharSet.Unicode)] // ���������� kernel32.dll � ��������� ��� ������� WritePrivateProfilesString
        public static extern int WritePrivateProfileString(string section, string key, string value, string filePath);

        [DllImport("kernel32", CharSet = CharSet.Unicode)] // ��� ��� ���������� kernel32.dll, � ������ ��������� ������� GetPrivateProfileString
        public static extern int GetPrivateProfileString(string section, string key, string Default, StringBuilder retVal, int size, string filePath);

        public static IEnumerable<object> GetResults(string win32ClassName, string property)
        {
            return (from x in new ManagementObjectSearcher("SELECT * FROM " + win32ClassName).Get().OfType<ManagementObject>()
                    select x.GetPropertyValue(property));
        }
        public static ulong? TotalInstalledBytes
        {
            get
            {
                var values = GetResults("Win32_PhysicalMemory", "Capacity");
                ulong? sum = null;
                foreach (var item in values)
                {
                    var casted = item as ulong?;
                    if (casted.HasValue)
                    {
                        if (sum == null) sum = 0;
                        sum += casted.Value;
                    }
                }
                return sum;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public const int WmUser = 0x8000;
        public const int WmUserIn = 0xC198;
        /// <summary>
        /// 
        /// </summary>
        public const int WmOpen = WmUser + 1;

        /// <summary>
        /// 
        /// </summary>
        public const int WmClose = WmUser + 2;

        /// <summary>
        /// 
        /// </summary>
        public const int WmEnable = WmUser + 3;

        /// <summary>
        /// 
        /// </summary>
        public const int WmDisable = WmUser + 4;

        /// <summary>
        /// 
        /// </summary>
        public static readonly IntPtr HwndBroadcast = new IntPtr(0xffff);

        /// <summary>
        /// 
        /// </summary>
        public const int SwHide = 0;

        /// <summary>
        /// 
        /// </summary>
        public const int SwShow = 5;

        /// <summary>
        /// 
        /// </summary>
        public const int WmSettingchange = 0x1a;

        /// <summary>
        /// 
        /// </summary>
        public const int SmtoAbortifhung = 0x0002;

        /// <summary>����� ���������� ����</summary>
        /// <param name="className">��� ������</param>
        /// <param name="windowName">��� ����</param>
        /// <returns>Handle ����</returns>
        [DllImport("user32.dll")]
        public static extern IntPtr FindWindow(string className, string windowName);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="hwndParent"></param>
        /// <param name="hwndChildAfter"></param>
        /// <param name="className"></param>
        /// <param name="windowName"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        public static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string className,
            string windowName);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="hWnd"></param>
        /// <param name="nCmdShow"></param>
        /// <returns></returns>
        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="hWnd"></param>
        /// <param name="msg"></param>
        /// <param name="wParam"></param>
        /// <param name="lParam"></param>
        /// <param name="fuFlags"></param>
        /// <param name="uTimeout"></param>
        /// <param name="lpdwResult"></param>
        /// <returns></returns>
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr SendMessageTimeout(IntPtr hWnd, int msg, int wParam, int lParam, uint fuFlags,
            uint uTimeout, IntPtr lpdwResult);

        /// <summary>������ ��� ����������� ������ �� �������� ����</summary>
        /// <param name="hWnd">��������� �� ������</param>
        /// <returns>��, ���-�� ������. ������ �������/�� �������</returns>
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        /// <summary>��������� ���������</summary>
        /// <param name="hWnd">��������� �� ����</param>
        /// <param name="msg">���������, �������� WmUser</param>
        /// <param name="wParam">������ ��������</param>
        /// <param name="lParam">������ ��������</param>
        /// <returns>An application should return zero if it processes this message.</returns>
        [DllImport("user32.dll")]
        public static extern uint SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);

        /// <summary>��������� ���������</summary>
        /// <param name="hWnd">��������� �� ����</param>
        /// <param name="msg">���������, �������� WmUser</param>
        /// <param name="wParam">������ ��������</param>
        /// <param name="lParam">������ ��������</param>
        /// <returns>An application should return zero if it processes this message.</returns>
        [DllImport("user32.dll")]
        public static extern bool PostMessage(IntPtr hWnd, uint msg, int wParam, int lParam);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        [DllImport("kernel32.dll")]
        public static extern int GlobalAddAtom(StringBuilder str);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nAtom"></param>
        /// <param name="lpBuffer"></param>
        /// <param name="nSize"></param>
        /// <returns></returns>
        [DllImport("kernel32.dll")]
        public static extern int GlobalGetAtomName(int nAtom, StringBuilder lpBuffer, int nSize);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="nAtom"></param>
        /// <returns></returns>
        [DllImport("kernel32.dll")]
        public static extern int GlobalDeleteAtom(int nAtom);

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindowThreadProcessId(IntPtr window, out int process);

        public static IntPtr[] GetProcessWindows(int processId)
        {
            List<IntPtr> apRet = new List<IntPtr>();
            IntPtr pLast = IntPtr.Zero;
            int counter=0;
            while (pLast == IntPtr.Zero)
            {
                pLast = FindWindowEx(IntPtr.Zero, pLast, null, "�����������");
                int iProcess;
                GetWindowThreadProcessId(pLast, out iProcess);
                if (pLast!= IntPtr.Zero && iProcess == processId) apRet.Add(pLast);
                counter++;
                if (counter > 1000) break;
            }
            return apRet.ToArray();
        }

    }
}