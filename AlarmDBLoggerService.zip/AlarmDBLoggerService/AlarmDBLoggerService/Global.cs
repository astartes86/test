﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlarmDBLoggerService
{
    class Global
    {
        public const string DtimeFormat = "dd.MM.yyyy HH:mm:ss";
        public static string TYPE = "type";
        public static string HOST = "host";
        public static string PORT = "port";
        public static string HOTSTANDBY = "hotstandby";
        public static string NAMEDB = "namedb";
        public static string PLC = "plc";
        public static string YES = "yes";
        public static string NO = "no";
        public static string ID = "id";
        public static string DB = "db";
        public static string ACKONCE = "1";
        public static string ACKALL = "2";
        public static string ARM = "250";
        public static string ISACK = "1";
        public static string PROVIDERL = "providerl";
        public static string DATASOURCEL = "datasourcel";
        public static string USERIDL = "useridl";
        public static string PASSWORDL = "passwordl";
        public static string INITCATALOGL = "initcatalogl";
        public static string CONNECTTIMEOUTL = "connecttimeoutl";
        public static string PROVIDERR = "providerr";
        public static string DATASOURCER = "datasourcer";
        public static string USERIDR = "useridr";
        public static string PASSWORDR = "passwordr";
        public static string INITCATALOGR = "initcatalogr";
        public static string CONNECTTIMEOUTR = "connecttimeoutr";
        public static string USERID = "userid";
        public static string PASSWORD = "password";
        public static string STRNOTACK = "Квитировать";
        public static string DIAG = "diag";
        public static string IP1 = "ip1";
        public static string ADRESS1 = "adress1";
        public static string IP2 = "ip2";
        public static string ADRESS2 = "adress2";
        public static string SYNCHDB = "synchdb";
        public static string SYNCHTAB = "synchtab";
        public static string TABLENAME = "tablename";
        public static string SHIFT = "shift";
        public static string STARTSYNCH = "startsynch";
        public static string MESSCLIENT = "";
        //public static Dictionary<int, Dictionary<DateTime,int>> UsedDateTimes = new Dictionary<int, Dictionary<DateTime, int>>();
        public static Dictionary<int, int> SystemAndShift = new Dictionary<int, int>();
        public static string SYSTEM = "system";
        public static string ACK = "ack";
        public static string ARMR = "armr";
        public static string DBcopy = "dbcopy";
        public static string PLCTYPE = "plctype";
        public static string PlcTypeQuantum = "quantum";
        public static string PlcTypeM340 = "m340";
        public static string PlcTypeM580 = "m580";
        public static string ButtTableName = "butttablename";
        public static string FromDB = "fromdb";
        public static string FromMySQLDB = "frommysqldb";
        public static string ToDB = "todb";
        public static string POLLTIMEOUT = "polltimeout";
        public static string NAMESYSTEM = "namesystem";
    }
}
