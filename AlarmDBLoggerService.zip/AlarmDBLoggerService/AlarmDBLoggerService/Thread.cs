﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Net.NetworkInformation;
using System.Collections.Specialized;
using System.Drawing;
using System.Globalization;
using System.Threading;
using Monitoring.Metrics;
using Timer = System.Threading.Timer;
//using static AlarmDBLoggerService.Constants;
using ActiveDLL;

namespace AlarmDBLoggerService
{

    public class Threads
    {
        private List<Thread> _threads; // создаем динамический список
        private string name;
        private DictionaryObject Objects;
        private DictionaryMessage Messages;

        public Threads() //конструктор будет принимать в себя ссылку на метод
        {       
        }

        private void MBmaster_OnException(ushort id, byte unit, byte function, byte exception)
        {
            string exc = "Ошибка соединения Modbus: ";
            switch (exception)
            {
                case modbus.excIllegalFunction: exc += "Неверная функция!"; break;
                case modbus.excIllegalDataAdr: exc += "Неверный адрес!"; break;
                case modbus.excIllegalDataVal: exc += "Неверное значение!"; break;
                case modbus.excSlaveDeviceFailure: exc += "Ошибка ведомого устройства!"; break;
                case modbus.excAck: exc += "Acknoledge!"; break;
                case modbus.excGatePathUnavailable: exc += "Gateway path unavailbale!"; break;
                case modbus.excExceptionTimeout: exc += "Slave timed out!"; break;
                case modbus.excExceptionConnectionLost: exc += "Обрыв соединения!"; break;
                case modbus.excExceptionNotConnected: exc += "Нет соединения!"; break;
            }
            Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + exc);
            Thread.Sleep(3000);
        }

        public void Run(List<string> names, List<Device> devices)
        {
            _threads = new List<Thread>();
            for (int i = 0; i < devices.Count; i++)
            {
                if (devices[i].getProperty(Global.TYPE).ToLower() == Global.PLC)
                {
                    name = names[i];

                    var thread = new Thread(PLCtoDB);
                    thread.Name = name;
                    thread.IsBackground = true; // закрываем форму и все потоки уничтожаются
                    _threads.Add(thread); // добавляем наш поток в динамический список
                    _threads[i].Start(devices[i]); // запускаем наш поток
                }

                if (devices[i].getProperty(Global.TYPE).ToLower() == Global.DB)
                {
                    name = names[i];
                    var thread = new Thread(DBtoDB);
                    thread.Name = name;
                    thread.IsBackground = true; // закрываем форму и все потоки уничтожаются
                    _threads.Add(thread); // добавляем наш поток в динамический список
                    _threads[i].Start(devices[i]); // запускаем наш поток
                }

                if (devices[i].getProperty(Global.TYPE).ToLower() == Global.DIAG)
                {
                    name = names[i];
                    var thread = new Thread(DIAG);
                    thread.Name = name;
                    thread.IsBackground = true; // закрываем форму и все потоки уничтожаются
                    _threads.Add(thread); // добавляем наш поток в динамический список
                    _threads[i].Start(devices[i]); // запускаем наш поток
                }

                if (devices[i].getProperty(Global.TYPE).ToLower() == Global.ACK)
                {
                    name = names[i];
                    var thread = new Thread(Ack);
                    thread.Name = name;
                    thread.IsBackground = true; // закрываем форму и все потоки уничтожаются
                    _threads.Add(thread); // добавляем наш поток в динамический список
                    _threads[i].Start(devices[i]); // запускаем наш поток
                }

                if (devices[i].getProperty(Global.TYPE).ToLower() == Global.DBcopy)
                {
                    name = names[i];
                    var thread = new Thread(DBtoDBcopy);
                    thread.Name = name;
                    thread.IsBackground = true; // закрываем форму и все потоки уничтожаются
                    _threads.Add(thread); // добавляем наш поток в динамический список
                    _threads[i].Start(devices[i]); // запускаем наш поток
                }

                if (devices[i].getProperty(Global.TYPE).ToLower() == Global.FromDB)
                {
                    name = names[i];
                    var thread = new Thread(FromDB);
                    thread.Name = name;
                    thread.IsBackground = true; // закрываем форму и все потоки уничтожаются
                    _threads.Add(thread); // добавляем наш поток в динамический список
                    _threads[i].Start(devices[i]); // запускаем наш поток
                }

				if (devices[i].getProperty(Global.TYPE).ToLower() == Global.FromMySQLDB)
                {
                    name = names[i];
                    var thread = new Thread(FromMySQLDB);
                    thread.Name = name;
                    thread.IsBackground = true; // закрываем форму и все потоки уничтожаются
                    _threads.Add(thread); // добавляем наш поток в динамический список
                    _threads[i].Start(devices[i]); // запускаем наш поток
                }																		
                Thread.Sleep(100);
            }

        }

        public void Abort()
        {
            foreach (Thread thread in _threads)
            {
                thread.Abort(); // уничтожаем поток
            }
            _threads.Clear(); // очищаем список
        }

        private enum PlcType
        {
            M340,
            M580,
            Quantum
        }

        /// <summary>
        /// Запись сообщений в БД
        /// </summary>
        private string WriteMessToDB(SqlDb SqlDb, int iStart, int iStop, byte[] Butt, string DateTime, Int32 IDmess, int shift, SqlDb.FieldType TypeDTime, ref Dictionary<DateTime, int> dtimes, out int msCount)
        {
            //Log.WriteLogToFile("Зашли - " + DateTime + " " + IDmess + " Сообщений = " + (iStop - iStart));
            DateTime DTime = new DateTime();
            int AddMs = 0;
            byte[] _Butt = Butt;
            int i = 1;
            for (int jj = iStart; jj <= iStop; jj++)
            {
                var SysID = _Butt[10 + (jj - 1) * 8]; //Идентификатор объекта
                if (SysID == 255)
                {
                    #region 

                    DateTime = "";

                    if (_Butt[14 + (jj - 1) * 8] < 10)
                    {
                        DateTime = DateTime + "0" + Convert.ToString(_Butt[14 + (jj - 1) * 8]) + ".";
                    }
                    else
                    {
                        DateTime = DateTime + Convert.ToString(_Butt[14 + (jj - 1) * 8]) + ".";
                    }

                    if (_Butt[13 + (jj - 1) * 8] < 10)
                    {
                        DateTime = DateTime + "0" + Convert.ToString(_Butt[13 + (jj - 1) * 8]) + ".";
                    }
                    else
                    {
                        DateTime = DateTime + Convert.ToString(_Butt[13 + (jj - 1) * 8]) + ".";
                    }

                    DateTime = DateTime + "20" + Convert.ToString(_Butt[12 + (jj - 1) * 8]) + " ";

                    if (_Butt[15 + (jj - 1) * 8] < 10)
                    {
                        DateTime = DateTime + "0" + Convert.ToString(_Butt[15 + (jj - 1) * 8]) + ":";
                    }
                    else
                    {
                        DateTime = DateTime + Convert.ToString(_Butt[15 + (jj - 1) * 8]) + ":";
                    }

                    if (_Butt[16 + (jj - 1) * 8] < 10)
                    {
                        DateTime = DateTime + "0" + Convert.ToString(_Butt[16 + (jj - 1) * 8]) + ":";
                    }
                    else
                    {
                        DateTime = DateTime + Convert.ToString(_Butt[16 + (jj - 1) * 8]) + ":";
                    }

                    if (_Butt[17 + (jj - 1) * 8] < 10)
                    {
                        DateTime = DateTime + "0" + Convert.ToString(_Butt[17 + (jj - 1) * 8]);
                    }
                    else
                    {
                        DateTime = DateTime + Convert.ToString(_Butt[17 + (jj - 1) * 8]);
                    }
                    i = 1;

                    #endregion
                }
                else
                {
                    DateTime dt;
                    if ((DateTime != "Null") && (System.DateTime.TryParse(DateTime.Substring(0, 10), out dt)) && (SysID != 0))
                    {
                        var Mess = _Butt[11 + (jj - 1) * 8]; //Код сообщения    
                        var SysNum = BitConverter.ToUInt16(_Butt, 12 + (jj - 1) * 8) + shift; //Номер объекта
                        var Val = BitConverter.ToSingle(_Butt, 14 + (jj - 1) * 8); //Значение
                        SqlDb.CreateDbCommand(
                        "INSERT INTO PLCMessage (IDmess, Place, DTime, dTimeAck, SysID, SysNum, Mess, Message, IsAck, Priority, Value) VALUES (@IDmess, @Place, @DTime, @dTimeAck, @SysID, @SysNum, @Mess, @Message, @IsAck, @Priority ,@Value)");
                        SqlDb.Command.Parameters.Add("@IDmess", SqlDbType.Decimal).Value = IDmess;
                        SqlDb.Command.Parameters.Add("@Place", SqlDbType.VarChar).Value = "PLC";
                        if (TypeDTime == SqlDb.FieldType.Datetime2 || TypeDTime == SqlDb.FieldType.Datetime)
                        {
                            DTime = Convert.ToDateTime(DateTime);
                            //if (i%10 == 8) i = i + 2;
                            var DTimeWrite = DTime.AddMilliseconds(i);
                            if (dtimes.ContainsKey(DTime))
                            {
                                AddMs = dtimes[DTime] - 1;
                                DTimeWrite = DTimeWrite.AddMilliseconds(AddMs);
                            }
                            //DTimeWrite = DTimeWrite.AddMilliseconds(msAdd);
                            SqlDb.Command.Parameters.Add("@DTime", SqlDbType.DateTime2).Value = DTimeWrite;
                        }
                        else
                        {
                            SqlDb.Command.Parameters.Add("@DTime", SqlDbType.VarChar).Value = DateTime;
                        }
                        if (SysID < 10)
                        {
                            if (Messages.getMessage("00" + Convert.ToString(SysID) + Convert.ToString(Mess)).isAck == 1)
                            {
                                SqlDb.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value = Global.STRNOTACK;
                            }
                            else
                            {
                                SqlDb.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value = "";
                            }
                        }
                        else if ((SysID >= 10) && (SysID < 100))
                        {
                            if (Messages.getMessage("0" + Convert.ToString(SysID) + Convert.ToString(Mess)).isAck == 1)
                            {
                                SqlDb.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value = Global.STRNOTACK;
                            }
                            else
                            {
                                SqlDb.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value = "";
                            }
                        }
                        else
                        {
                            if (Messages.getMessage(Convert.ToString(SysID) + Convert.ToString(Mess)).isAck == 1)
                            {
                                SqlDb.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value = Global.STRNOTACK;
                            }
                            else
                            {
                                SqlDb.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value = "";
                            }
                        }
                        SqlDb.Command.Parameters.Add("@SysID", SqlDbType.Int).Value = SysID;
                        SqlDb.Command.Parameters.Add("@SysNum", SqlDbType.Int).Value = SysNum;
                        SqlDb.Command.Parameters.Add("@Mess", SqlDbType.Int).Value = Mess;
                        if (SysID < 10)
                        {
                            SqlDb.Command.Parameters.Add("@Message", SqlDbType.VarChar).Value =
                                Objects.getObject("00" + Convert.ToString(SysID) + Convert.ToString(SysNum)).Name + ". " +
                                Messages.getMessage("00" + Convert.ToString(SysID) + Convert.ToString(Mess)).Mess;
                            SqlDb.Command.Parameters.Add("@isAck", SqlDbType.Int).Value =
                                Messages.getMessage("00" + Convert.ToString(SysID) + Convert.ToString(Mess)).isAck;
                            SqlDb.Command.Parameters.Add("@Priority", SqlDbType.Int).Value =
                                Messages.getMessage("00" + Convert.ToString(SysID) + Convert.ToString(Mess)).Priority;
                        }
                        else if ((SysID >= 10) && (SysID < 100))
                        {
                            SqlDb.Command.Parameters.Add("@Message", SqlDbType.VarChar).Value =
                                Objects.getObject("0" + Convert.ToString(SysID) + Convert.ToString(SysNum)).Name + ". " +
                                Messages.getMessage("0" + Convert.ToString(SysID) + Convert.ToString(Mess)).Mess;
                            SqlDb.Command.Parameters.Add("@isAck", SqlDbType.Int).Value =
                                Messages.getMessage("0" + Convert.ToString(SysID) + Convert.ToString(Mess)).isAck;
                            SqlDb.Command.Parameters.Add("@Priority", SqlDbType.Int).Value =
                                Messages.getMessage("0" + Convert.ToString(SysID) + Convert.ToString(Mess)).Priority;
                        }
                        else
                        {
                            SqlDb.Command.Parameters.Add("@Message", SqlDbType.VarChar).Value =
                                Objects.getObject(Convert.ToString(SysID) + Convert.ToString(SysNum)).Name + ". " +
                                Messages.getMessage(Convert.ToString(SysID) + Convert.ToString(Mess)).Mess;
                            SqlDb.Command.Parameters.Add("@isAck", SqlDbType.Int).Value =
                                Messages.getMessage(Convert.ToString(SysID) + Convert.ToString(Mess)).isAck;
                            SqlDb.Command.Parameters.Add("@Priority", SqlDbType.Int).Value =
                                Messages.getMessage(Convert.ToString(SysID) + Convert.ToString(Mess)).Priority;
                        }
                        if (float.IsNaN(Val) || (Val == -3.402823E+38))                 //по просьбе Гриши
                        {
                            SqlDb.Command.Parameters.Add("@Value", SqlDbType.VarChar).Value = "NaN";
                        }
                        else
                        {
                            SqlDb.Command.Parameters.Add("@Value", SqlDbType.VarChar).Value = Val;
                        }
                        SqlDb.Command.ExecuteNonQuery();
                        i++;
                    }
                }
            }
            // (!dtimes.ContainsKey(DTime)) dtimes.Add(DTime, i);
            msCount = i + AddMs;
            //Log.WriteLogToFile("Вышли - " + DateTime + " " + IDmess + " Сообщений = " + (iStop - iStart) + " AddMs = " + AddMs + " msCount = " + msCount);
            return DateTime;
        }

        /// <summary>
        /// Запись  и расшифровка сообщений из ПЛК в БД
        /// </summary>
        /// <param name="dev"></param>
        [SuppressMessage("ReSharper", "TooWideLocalVariableScope")]
        [SuppressMessage("ReSharper", "JoinDeclarationAndInitializer")]
        private void PLCtoDB(object dev)
        {
            #region Инициализация

            Device d = (Device)dev;
            //Объект тип устройства
            modbus modbusTCP = new modbus(); //Объект типа Модбас
            string[] ip = d.getProperty(Global.HOST).Split(new char[] { '|' });
            string ip_mess = "";
            int i = 0;
            //string ip = d.getProperty(Global.HOST);
            ushort port = (ushort)Convert.ToInt16(d.getProperty(Global.PORT));
            ushort ID = 3; //3 функция модбас
            byte unit = 1; //ID устройства
            int shift = 0; //смещение для разных плк
            PlcType plcType = PlcType.Quantum; //тип ПЛК
            int sdvig = 0;

            //string connectionString = "Provider=" + d.getProperty(Global.PROVIDERL) + ";Data Source=" + d.getProperty(Global.DATASOURCEL) +
            //                          ";Password=" + CRYPT.Crypt.GetPassword(d.getProperty(Global.PASSWORDL)) + ";User ID=" + d.getProperty(Global.USERIDL) +
            //                          ";Initial Catalog=" + d.getProperty(Global.INITCATALOGL) + ";Connect Timeout=" + d.getProperty(Global.CONNECTTIMEOUTL);
            string connectionString = "Data Source=" + d.getProperty(Global.DATASOURCEL) + ";Password=" +
                                      Crypt.GetPassword(d.getProperty(Global.PASSWORDL)) +
                                      ";User ID=" + d.getProperty(Global.USERIDL) + ";Initial Catalog=" +
                                      d.getProperty(Global.INITCATALOGL) +
                                      ";Connect Timeout=" + d.getProperty(Global.CONNECTTIMEOUTL);
            Log.WriteLogToFile(Thread.CurrentThread.Name + "Строка подключения - " + connectionString);
            var SqlDb = new SqlDb(connectionString);
            if (d.getProperty(Global.SHIFT) != "") shift = Convert.ToInt32(d.getProperty(Global.SHIFT));
            if (d.getProperty(Global.PLCTYPE) != "")
            {
                var prop = d.getProperty(Global.PLCTYPE);
                if (prop == Global.PlcTypeQuantum) plcType = PlcType.Quantum;
                else if (prop == Global.PlcTypeM340) plcType = PlcType.M340;
                else if (prop == Global.PlcTypeM580) plcType = PlcType.M580;
            }
            switch (plcType)
            {
                case PlcType.M340:
                    sdvig = 6;
                    break;
                case PlcType.M580:
                    sdvig = 6;
                    break;
                case PlcType.Quantum:
                    sdvig = 0;
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
            //Dictionary<string, string> _Objects = new Dictionary<string, string>();                //Словарь для объектов чтобы помнить
            Dictionary<int, ushort> Butt = new Dictionary<int, ushort>(); //Словарь для хранения бочек и их адресов
            int NOldButt; //Номер последней считанной бочки
            int NNewButt; //Номер новой бочки
            int NOldMess; //Номер последнего прочитанного сообщения глобальный
            int NNewMess; //Номер нового сообщения глобальный
            int NOldMess_loc; //Номер последнего прочитанного сообщения локальный (макс = Нсооб*Нбочки)
            int NNewMess_loc; //Номер нового сообщения лок4альный
            int NOldMess_butt; //Номер последнего прочитанного сообщения в бочке
            int NNewMess_butt; //Номер нового сообщения в бочке
            string DateTime = "Null"; //Метка времени
            byte[] _Butt = new byte[250]; //Массив данных получаемых по Модбас
            int i_Start; //Старт для цикла
            int i_Stop; //Стоп для цикла
            byte[] Nmessout = new byte[18]; //Массив для выдачи сообщений о пропусках
            modbusTCP.OnException += MBmaster_OnException;
            int _system = 1;
            SqlDb.FieldType dtimeDataType = SqlDb.FieldType.Nvarchar;
            if (d.getProperty(Global.SYSTEM) != "") _system = Convert.ToInt32(d.getProperty(Global.SYSTEM));
            Dictionary<DateTime, int> dtimes = new Dictionary<DateTime, int>();
            string buttTableName = d.getProperty(Global.ButtTableName);
            if (string.IsNullOrEmpty(buttTableName)) buttTableName = "BUTTSETUP";

            try
            {
                if (!Global.SystemAndShift.ContainsKey(_system))
                    Global.SystemAndShift.Add(_system, shift);
                //добавляем в словарик значения номер системы и ее shift для будущего поиска IDMESS
            }
            catch (Exception ex)
            {
                Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
            }

            #endregion

            #region Связь

            bool connected = false;
            while (!connected)
            {
                try
                {
                    SqlDb = new SqlDb(connectionString);
                    SqlDb.Open();
                    Thread.Sleep(100);
                    dtimeDataType = SqlDb.GetFieldType();
                    SqlDb.Reader.Close();
                    connected = true;
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                    Thread.Sleep(10000);
                    continue;
                }
            }

            var counter = 0;
            do
            {
                Thread.Sleep(3000);
                Objects = new DictionaryObject(connectionString);
                Messages = new DictionaryMessage(connectionString);
                counter++;
                if (counter > 10) {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + "Ошибка чтения таблиц Object и/или Message");
                    counter = 0;
                }
            } while (Objects.Count == 0 || Messages.Count == 0); //защита когда объекты пустые

            #endregion

            #region Чтение бочек  из базы

            if (!SqlDb.SqlConnected())
            {
                SqlDb = new SqlDb(connectionString);
                SqlDb.Open();
            }
            SqlDb.CreateDbCommand("SELECT NButt, AdrButt FROM " + buttTableName);
            SqlDb.ExecuteReader();
            while (SqlDb.Reader.Read())
            {
                Butt[Convert.ToByte(SqlDb.Reader["NButt"])] = Convert.ToUInt16(SqlDb.Reader["AdrButt"]);
            }
            SqlDb.Reader.Close();

            #endregion

            #region Определение последней метки ПЛК - IDmess

            if (Global.SystemAndShift.Count > 1) //если число систем > 1
            {
                if (Global.SystemAndShift.ContainsKey(_system + 1)) //если есть система впереди
                {
                    SqlDb.CreateDbCommand("SELECT TOP (1) IDmess FROM PLCMessage WHERE (Place = 'PLC') and (SYSNUM > " + Global.SystemAndShift[_system] + ") and (SYSNUM < " + Global.SystemAndShift[_system + 1] + ") ORDER BY ID DESC");
                }
                else if (Global.SystemAndShift.ContainsKey(_system - 1)) //если есть система позади но нет впереди
                {
                    SqlDb.CreateDbCommand("SELECT TOP (1) IDmess FROM PLCMessage WHERE (Place = 'PLC') and (SYSNUM > " + Global.SystemAndShift[_system] + ") ORDER BY ID DESC");
                }
            }
            else
            {
                SqlDb.CreateDbCommand("SELECT TOP (1) IDmess FROM PLCMessage WHERE (Place = 'PLC') ORDER BY ID DESC"); //обычный запрос когда одна система
            }

            SqlDb.ExecuteReader();


            NOldMess = 0;
            NOldMess_loc = 0;
            NOldMess_butt = 0;
            NOldButt = 1;

            while (SqlDb.Reader.Read())
            {
                if (SqlDb.Reader["IDmess"] == null) continue;
                NOldMess = Convert.ToInt32(SqlDb.Reader["IDmess"]);
                //MessageBox.Show(d.name() +" "+ NOldMess.ToString());
                if (NOldMess == 0)
                {
                    NOldMess_loc = 0;
                    NOldMess_butt = 0;
                    NOldButt = 1;
                }
                else
                {
                    NOldMess_loc = (NOldMess) - ((NOldMess) / (Butt.Count * 30)) * (Butt.Count * 30);
                    if (NOldMess_loc == 0)
                    {
                        NOldMess_butt = 0;
                        NOldButt = 1;
                    }
                    else
                    {
                        if ((NOldMess_loc - (NOldMess_loc / 30) * 30) == 0)
                        {
                            NOldButt = NOldMess_loc / 30;
                        }
                        else
                        {
                            NOldButt = (NOldMess_loc / 30) + 1;
                        }
                        NOldMess_butt = NOldMess_loc - (NOldMess_loc / 30) * 30;
                    }
                }
            }
            SqlDb.Reader.Close();

            #endregion

            #region Основной цикл

            while (true)
            {
                #region СВЯЗЬ
                try
                {
                    if (!modbusTCP.Socketconnected()) //если нет связи
                    {
                        if (i > ip.Length - 1) i = 0;
                        ip_mess = ip[i];
                        modbusTCP.connect(ip[i], port);
                        if (!modbusTCP.Socketconnected()) i++;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                    Thread.Sleep(3000);
                    i++;
                    continue;
                }

                #endregion

                try
                {
                    if (!SqlDb.SqlConnected())
                    {
                        SqlDb = new SqlDb(connectionString);
                        SqlDb.Open();
                    }
                    modbusTCP.frame = 0;
                    modbusTCP.ReadHoldingRegister(ID, unit, Butt[NOldButt], 125, ref _Butt);
                    if (_Butt == null) continue;


                    #region NNewMess

                    NNewMess = BitConverter.ToInt32(_Butt, sdvig);
                    if (NNewMess == 0)
                    {
                        NNewMess_loc = 0;
                        NNewMess_butt = 0;
                        NNewButt = 1;
                    }
                    else
                    {
                        NNewMess_loc = (NNewMess) - ((NNewMess) / (Butt.Count * 30)) * (Butt.Count * 30);
                        if (NNewMess_loc == 0)
                        {
                            NNewMess_butt = 0;
                            NNewButt = 1;
                        }
                        else
                        {
                            if ((NNewMess_loc - (NNewMess_loc / 30) * 30) == 0)
                            {
                                NNewButt = NNewMess_loc / 30;
                                NNewMess_butt = 30;
                            }
                            else
                            {
                                NNewButt = (NNewMess_loc / 30) + 1;
                                NNewMess_butt = NNewMess_loc - (NNewMess_loc / 30) * 30;
                            }
                        }
                    }

                    #endregion

                    int ms;
                    DateTime dt = new DateTime();

                    #region Запись

                    if ((NNewMess - NOldMess) >= (Butt.Count * 30))
                    {
                        Nmessout[10] = 254; // SysId
                        Nmessout[11] = 1; // Mess
                        Array.Copy(BitConverter.GetBytes((Int16)1), 0, Nmessout, 12, 2);
                        Array.Copy(BitConverter.GetBytes((Single)((NNewMess - NOldMess) - (Butt.Count * 30))), 0,
                            Nmessout, 14, 4);
                        DateTime = WriteMessToDB(SqlDb, 1, 1, Nmessout, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                        try
                        {
                            if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                            if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms);
                            else
                            {
                                dtimes[dt] = ms;
                            }
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                        }
                        if ((NNewButt == Butt.Count * 30) && (NNewMess_butt == 30))
                        {
                            for (int j = 1; j <= (Butt.Count * 30); j++)
                            {
                                modbusTCP.ReadHoldingRegister(ID, unit, Butt[j], 125, ref _Butt);
                                //qqq++;
                                if (_Butt == null) continue;

                                DateTime = WriteMessToDB(SqlDb, 1, 30, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                try
                                {
                                    if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                    if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                }
                                catch (Exception ex)
                                {
                                    Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                }
                            }
                        }
                        else
                        {
                            if (NNewMess_butt == 30)
                            {
                                i_Start = NNewButt + 1;
                                i_Stop = (Butt.Count);
                            }
                            else
                            {
                                i_Start = NNewButt;
                                i_Stop = (Butt.Count);
                            }

                            for (int j = i_Start; j <= i_Stop; j++)
                            {
                                if (j > NNewButt)
                                {
                                    modbusTCP.ReadHoldingRegister(ID, unit, Butt[j], 125, ref _Butt);

                                    //qqq++;
                                    if (_Butt == null) continue;
                                    DateTime = WriteMessToDB(SqlDb, 1, 30, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                                else
                                {
                                    DateTime = WriteMessToDB(SqlDb, NNewMess_butt + 1, 30, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                            }

                            i_Start = 1;
                            i_Stop = NNewButt;

                            for (int j = i_Start; j <= i_Stop; j++)
                            {
                                modbusTCP.ReadHoldingRegister(ID, unit, Butt[j], 125, ref _Butt);
                                //qqq++;
                                if (_Butt == null) continue;
                                if (j < NNewButt)
                                {
                                    DateTime = WriteMessToDB(SqlDb, 1, 30, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                                else
                                {
                                    DateTime = WriteMessToDB(SqlDb, 1, NNewMess_butt, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                            }
                        }

                    }
                    else if ((NNewMess - NOldMess) != 0)
                    {

                        if ((NOldButt == (Butt.Count)) && (NOldMess_butt == 30))
                        {
                            i_Start = 1;
                            i_Stop = NNewButt;

                            for (int j = i_Start; j <= i_Stop; j++)
                            {
                                modbusTCP.ReadHoldingRegister(ID, unit, Butt[j], 125, ref _Butt);
                                if (_Butt == null) continue;
                                if (j < NNewButt)
                                {
                                    DateTime = WriteMessToDB(SqlDb, 1, 30, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                                else
                                {
                                    DateTime = WriteMessToDB(SqlDb, 1, NNewMess_butt, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                            }
                        }
                        else if (NNewMess_loc > NOldMess_loc)
                        {
                            if (NOldMess_butt == 30)
                            {
                                i_Start = NOldButt + 1;
                                i_Stop = NNewButt;
                            }
                            else
                            {
                                i_Start = NOldButt;
                                i_Stop = NNewButt;
                            }
                            for (int j = i_Start; j <= i_Stop; j++)
                            {
                                if ((j > NOldButt) && (j < NNewButt))
                                {
                                    modbusTCP.ReadHoldingRegister(ID, unit, Butt[j], 125, ref _Butt);
                                    if (_Butt == null) continue;
                                    DateTime = WriteMessToDB(SqlDb, 1, 30, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                                else if ((j == NOldButt) && (j == NNewButt))
                                {
                                    DateTime = WriteMessToDB(SqlDb, NOldMess_butt + 1, NNewMess_butt, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                                else if ((j == NOldButt))
                                {
                                    DateTime = WriteMessToDB(SqlDb, NOldMess_butt + 1, 30, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                                else if ((j == NNewButt))
                                {
                                    modbusTCP.ReadHoldingRegister(ID, unit, Butt[j], 125, ref _Butt);
                                    if (_Butt == null) continue;
                                    DateTime = WriteMessToDB(SqlDb, 1, NNewMess_butt, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                            }
                        }
                        else if (NNewMess_loc < NOldMess_loc)
                        {
                            if (NOldMess_butt == 30)
                            {
                                i_Start = NOldButt + 1;
                                i_Stop = (Butt.Count);
                            }
                            else
                            {
                                i_Start = NOldButt;
                                i_Stop = (Butt.Count);
                            }

                            for (int j = i_Start; j <= i_Stop; j++)
                            {
                                if (j > NOldButt)
                                {
                                    modbusTCP.ReadHoldingRegister(ID, unit, Butt[j], 125, ref _Butt);
                                    if (_Butt == null) continue;
                                    DateTime = WriteMessToDB(SqlDb, 1, 30, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                                else
                                {
                                    DateTime = WriteMessToDB(SqlDb, NOldMess_butt + 1, 30, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                            }

                            i_Start = 1;
                            i_Stop = NNewButt;

                            for (int j = i_Start; j <= i_Stop; j++)
                            {
                                modbusTCP.ReadHoldingRegister(ID, unit, Butt[j], 125, ref _Butt);
                                if (_Butt == null) continue;
                                if (j < NNewButt)
                                {
                                    DateTime = WriteMessToDB(SqlDb, 1, 30, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                                else
                                {
                                    DateTime = WriteMessToDB(SqlDb, 1, NNewMess_butt, _Butt, DateTime, NNewMess, shift, dtimeDataType, ref dtimes, out ms);
                                    try
                                    {
                                        if (DateTime != "Null") dt = Convert.ToDateTime(DateTime);
                                        if (!dtimes.ContainsKey(dt)) dtimes.Add(dt, ms); else { dtimes[dt] = ms; }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                                    }
                                }
                            }
                        }
                    }

                    #endregion

                    NOldButt = NNewButt;
                    NOldMess = NNewMess;
                    NOldMess_butt = NNewMess_butt;
                    NOldMess_loc = NNewMess_loc;

                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " - " + ex.Message);
                    Thread.Sleep(3000);
                }
                Thread.Sleep(100);
            }
            #endregion
        }

        /// <summary>
        /// Пересылка сервисных сообщений
        /// </summary>
        /// <param name="dev"></param>
        private void DBtoDB(object dev)
        {
            Device d = (Device)dev; //Объект тип устройства
            bool FirstScan = true;
            int LocalNew = 0;
            int LocalOld = 0;
            int i = 0;
            string[] _datasource = d.getProperty(Global.DATASOURCER).Split(new char[] { '|' });

            string connectionString = "Data Source=" + d.getProperty(Global.DATASOURCEL) + ";Password=" + Crypt.GetPassword(d.getProperty(Global.PASSWORDL)) + ";User ID=" + d.getProperty(Global.USERIDL) + ";Initial Catalog=" + d.getProperty(Global.INITCATALOGL) + ";Connect Timeout=" + d.getProperty(Global.CONNECTTIMEOUTL);
            var SqlDbLocal = new SqlDb(connectionString);
            string connectionStringR = "";
            var SqlDbRemote = new SqlDb(connectionStringR);

            #region Ждем соединения с БД

            Thread.Sleep(3000);
            bool firstConnect = false;
            while (!firstConnect)
            {
                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal.Open();
                        SqlDbLocal.GetFieldType();
                        i = 0;
                    }
                    if (i > _datasource.Length - 1) i = 0;
                    connectionStringR = "Data Source=" + _datasource[i] + ";Password=" +
                                               Crypt.GetPassword(d.getProperty(Global.PASSWORDR)) + ";User ID=" +
                                               d.getProperty(Global.USERIDR) + ";Initial Catalog=" +
                                               d.getProperty(Global.INITCATALOGR) + ";Connect Timeout=" +
                                               d.getProperty(Global.CONNECTTIMEOUTR);
                    SqlDbRemote = new SqlDb(connectionStringR);
                    if (!SqlDbRemote.SqlConnected())
                    {
                        SqlDbRemote.Open();
                        SqlDbRemote.GetFieldType();

                    }
                    firstConnect = true;
                    SqlDbLocal.Close();
                    SqlDbRemote.Close();
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка подключения к БД. Попытка подключения через 3 сек... - " + ex.Message);
                    i++;
                    Thread.Sleep(3000);
                }
            }

            #endregion

            if (SqlDbLocal.UseDateTimeInPlcMessage != SqlDbRemote.UseDateTimeInPlcMessage)
            {
                Log.WriteLogToFile(Thread.CurrentThread.Name + " Базы с разными типами. Возможна нестабильная работа блока");
            }
            var dateTimeFormat = SqlDbRemote.UseDateTimeInPlcMessage && SqlDbLocal.UseDateTimeInPlcMessage;
            Queue<DbMess> listMess = new Queue<DbMess>();
            while (true)
            {
               #region 
                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal = new SqlDb(connectionString);
                        SqlDbLocal.Open();
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }

                try
                {
                    if (!SqlDbRemote.SqlConnected())
                    {
                        if (i > _datasource.Length - 1) i = 0;
                        connectionStringR = "Data Source=" + _datasource[i] + ";Password=" +
                                               Crypt.GetPassword(d.getProperty(Global.PASSWORDR)) + ";User ID=" +
                                               d.getProperty(Global.USERIDR) + ";Initial Catalog=" +
                                               d.getProperty(Global.INITCATALOGR) + ";Connect Timeout=" +
                                               d.getProperty(Global.CONNECTTIMEOUTR);
                        SqlDbRemote = new SqlDb(connectionStringR);
                        SqlDbRemote.Open();
                        FirstScan = true;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка удаленной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    i++;
                    continue;
                }
                #endregion

                #region FirstScan

                if (FirstScan)
                {
                    try
                    {
                        if (!SqlDbLocal.SqlConnected())
                        {
                            SqlDbLocal = new SqlDb(connectionString);
                            SqlDbLocal.Open();
                        }
                        SqlDbLocal.CreateDbCommand("SELECT TOP(1)ID FROM PLCMessage ORDER BY ID DESC");
                        SqlDbLocal.ExecuteReader();
                        while (SqlDbLocal.Reader.Read())
                        {
                            LocalOld = Convert.ToInt32(SqlDbLocal.Reader["ID"]);
                        }
                        SqlDbLocal.Reader.Close();
                        FirstScan = false;
                    }
                    catch (Exception ex)
                    {
                        Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД на FirstScan - " + ex.Message);
                        Thread.Sleep(1000);
                        continue;
                    }
                }

                #endregion
                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal = new SqlDb(connectionString);
                        SqlDbLocal.Open();
                    }
                    SqlDbLocal.CreateDbCommand("SELECT TOP(1)ID FROM PLCMessage ORDER BY ID DESC");
                    SqlDbLocal.ExecuteReader();
                    while (SqlDbLocal.Reader.Read())
                    {
                        LocalNew = Convert.ToInt32(SqlDbLocal.Reader["ID"]);
                    }
                    SqlDbLocal.Reader.Close();
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }
                try
                {
                    if (LocalOld != LocalNew)
                    {
                        if (!SqlDbLocal.SqlConnected())
                        {
                            SqlDbLocal = new SqlDb(connectionString);
                            SqlDbLocal.Open();
                        }
                        SqlDbLocal.CreateDbCommand("SELECT * FROM PLCMessage WHERE ((ID > @IDOLD) AND (ID <= @IDNEW))");
                        SqlDbLocal.Command.Parameters.Add("@IDOLD", SqlDbType.Int).Value = LocalOld;
                        SqlDbLocal.Command.Parameters.Add("@IDNEW", SqlDbType.Int).Value = LocalNew;
                        SqlDbLocal.ExecuteReader();
                        while (SqlDbLocal.Reader.Read())
                        {
                            var messNum = Convert.ToInt32(SqlDbLocal.Reader["Mess"]);
                            var place = Convert.ToString(SqlDbLocal.Reader["Place"]);
                            if (String.Equals(place, Environment.MachineName, StringComparison.CurrentCultureIgnoreCase) && (messNum < 100 || messNum > 110))
                            {
                                DbMess mess = new DbMess(
                                Convert.ToInt32(SqlDbLocal.Reader["IDmess"]),
                                place,
                                Convert.ToDateTime(SqlDbLocal.Reader["DTime"]),
                                Convert.ToString(SqlDbLocal.Reader["DTimeAck"]),
                                Convert.ToInt32(SqlDbLocal.Reader["SysID"]),
                                Convert.ToInt32(SqlDbLocal.Reader["SysNum"]),
                                messNum,
                                Convert.ToString(SqlDbLocal.Reader["Message"]),
                                Convert.ToInt32(SqlDbLocal.Reader["isAck"]),
                                Convert.ToInt32(SqlDbLocal.Reader["Priority"]),
                                Convert.ToString(SqlDbLocal.Reader["Value"])
                                );
                                if (listMess.Count < 20000) listMess.Enqueue(mess);
                            }
                        }
                        SqlDbLocal.Reader.Close();
                        LocalOld = LocalNew;
                        Thread.Sleep(100);
                    }

                    while (listMess.Count > 0)
                    {
                        if (!SqlDbRemote.SqlConnected())
                        {
                            SqlDbRemote = new SqlDb(connectionStringR);
                            SqlDbRemote.Open();
                        }
                        DbMess dmMess = listMess.Peek();
                        SqlDbRemote.CreateDbCommand(
                            "INSERT INTO PLCMessage (IDmess, Place, DTime, dTimeAck, SysID, SysNum, Mess, Message, IsAck, Priority, Value) " +
                            "VALUES (@IDmess, @Place, @DTime, @dTimeAck, @SysID, @SysNum, @Mess, @Message, @IsAck, @Priority ,@Value)");
                        SqlDbRemote.Command.Parameters.Add("@IDmess", SqlDbType.Int).Value = dmMess.IDmess;
                        SqlDbRemote.Command.Parameters.Add("@Place", SqlDbType.NVarChar).Value = dmMess.Place;
                        if (dateTimeFormat)
                        {
                            SqlDbRemote.Command.Parameters.Add("@DTime", SqlDbType.DateTime2).Value = dmMess.DTime;
                        }
                        else
                        {
                            SqlDbRemote.Command.Parameters.Add("@DTime", SqlDbType.NVarChar).Value =
                                dmMess.DTime.ToString(Global.DtimeFormat);
                        }
                        SqlDbRemote.Command.Parameters.Add("@dTimeAck", SqlDbType.NVarChar).Value = dmMess.DTimeAck;
                        SqlDbRemote.Command.Parameters.Add("@SysID", SqlDbType.Int).Value = dmMess.SysID;
                        SqlDbRemote.Command.Parameters.Add("@SysNum", SqlDbType.Int).Value = dmMess.SysNum;
                        SqlDbRemote.Command.Parameters.Add("@Mess", SqlDbType.Int).Value = dmMess.Mess;
                        SqlDbRemote.Command.Parameters.Add("@Message", SqlDbType.NVarChar).Value = dmMess.Message;
                        SqlDbRemote.Command.Parameters.Add("@IsAck", SqlDbType.Int).Value = dmMess.isAck;
                        SqlDbRemote.Command.Parameters.Add("@Priority", SqlDbType.Int).Value = dmMess.Priority;
                        SqlDbRemote.Command.Parameters.Add("@Value", SqlDbType.NVarChar).Value = dmMess.Value;
                        SqlDbRemote.Command.ExecuteNonQuery();
                        listMess.Dequeue();
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + "Ошибка чтения-записи БД ops - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }
                Thread.Sleep(1000);
            }
        }

        /// <summary>
        /// Пересылка всех сообщений
        /// </summary>
        /// <param name="dev"></param>
        private void DBtoDBcopy(object dev)
        {
            Device d = (Device)dev; //Объект тип устройства
            bool FirstScan = true;
            int LocalNew = 0;
            int LocalOld = 0;
            int i = 0;
            string[] _datasource = d.getProperty(Global.DATASOURCER).Split(new char[] { '|' });
            int count = 99;
            string connectionString = "Data Source=" + d.getProperty(Global.DATASOURCEL) + ";Password=" + Crypt.GetPassword(d.getProperty(Global.PASSWORDL)) + ";User ID=" + d.getProperty(Global.USERIDL) + ";Initial Catalog=" + d.getProperty(Global.INITCATALOGL) + ";Connect Timeout=" + d.getProperty(Global.CONNECTTIMEOUTL);
            var SqlDbLocal = new SqlDb(connectionString);
            string connectionStringR = "";
            var SqlDbRemote = new SqlDb(connectionStringR);

            #region Ждем соединения с БД

            Thread.Sleep(3000);
            bool firstConnect = false;
            while (!firstConnect)
            {
                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal.Open();
                        SqlDbLocal.GetFieldType();
                        i = 0;
                    }
                    if (i > _datasource.Length - 1) i = 0;
                    connectionStringR = "Data Source=" + _datasource[i] + ";Password=" +
                                               Crypt.GetPassword(d.getProperty(Global.PASSWORDR)) + ";User ID=" +
                                               d.getProperty(Global.USERIDR) + ";Initial Catalog=" +
                                               d.getProperty(Global.INITCATALOGR) + ";Connect Timeout=" +
                                               d.getProperty(Global.CONNECTTIMEOUTR);
                    SqlDbRemote = new SqlDb(connectionStringR);
                    if (!SqlDbRemote.SqlConnected())
                    {
                        SqlDbRemote.Open();
                        SqlDbRemote.GetFieldType();

                    }
                    firstConnect = true;
                    SqlDbLocal.Close();
                    SqlDbRemote.Close();
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка подключения к БД. Попытка подключения через 3 сек... - "+ex.Message);
                    i++;
                    Thread.Sleep(3000);
                }
            }

            #endregion

            if (SqlDbLocal.UseDateTimeInPlcMessage != SqlDbRemote.UseDateTimeInPlcMessage)
            {
                Log.WriteLogToFile(Thread.CurrentThread.Name + " Базы с разными типами. Возможна нестабильная работа блока");
            }
            var dateTimeFormat = SqlDbRemote.UseDateTimeInPlcMessage && SqlDbLocal.UseDateTimeInPlcMessage;
            Queue<DbMess> listMess = new Queue<DbMess>();
            while (true)
            {

                #region 
                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal = new SqlDb(connectionString);
                        SqlDbLocal.Open();
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }

                try
                {
                    if (!SqlDbRemote.SqlConnected())
                    {
                        if (i > _datasource.Length - 1) i = 0;
                        connectionStringR = "Data Source=" + _datasource[i] + ";Password=" +
                                               Crypt.GetPassword(d.getProperty(Global.PASSWORDR)) + ";User ID=" +
                                               d.getProperty(Global.USERIDR) + ";Initial Catalog=" +
                                               d.getProperty(Global.INITCATALOGR) + ";Connect Timeout=" +
                                               d.getProperty(Global.CONNECTTIMEOUTR);
                        SqlDbRemote = new SqlDb(connectionStringR);
                        SqlDbRemote.Open();
                        FirstScan = true;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка удаленной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    i++;
                    continue;
                }
                #endregion
                #region FirstScan

                if (FirstScan)
                {
                    try
                    {
                        if (!SqlDbLocal.SqlConnected())
                        {
                            SqlDbLocal = new SqlDb(connectionString);
                            SqlDbLocal.Open();
                        }
                        SqlDbLocal.CreateDbCommand("SELECT TOP(1)ID FROM PLCMessage ORDER BY ID DESC");
                        SqlDbLocal.ExecuteReader();
                        while (SqlDbLocal.Reader.Read())
                        {
                            LocalOld = Convert.ToInt32(SqlDbLocal.Reader["ID"]);
                        }
                        SqlDbLocal.Reader.Close();
                        FirstScan = false;
                    }
                    catch (Exception ex)
                    {
                        Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД на FirsScan - " + ex.Message);
                        Thread.Sleep(1000);
                        continue;
                    }
                }

                #endregion
                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal = new SqlDb(connectionString);
                        SqlDbLocal.Open();
                    }
                    SqlDbLocal.CreateDbCommand("SELECT TOP(1)ID FROM PLCMessage ORDER BY ID DESC");
                    SqlDbLocal.ExecuteReader();
                    while (SqlDbLocal.Reader.Read())
                    {
                        LocalNew = Convert.ToInt32(SqlDbLocal.Reader["ID"]);
                    }
                    SqlDbLocal.Reader.Close();
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }
                try
                {
                    if (LocalOld != LocalNew)
                    {
                        if (!SqlDbLocal.SqlConnected())
                        {
                            SqlDbLocal = new SqlDb(connectionString);
                            SqlDbLocal.Open();
                        }
                        SqlDbLocal.CreateDbCommand("SELECT * FROM PLCMessage WHERE ((ID > @IDOLD) AND (ID <= @IDNEW))");
                        SqlDbLocal.Command.Parameters.Add("@IDOLD", SqlDbType.Int).Value = LocalOld;
                        SqlDbLocal.Command.Parameters.Add("@IDNEW", SqlDbType.Int).Value = LocalNew;
                        SqlDbLocal.ExecuteReader();
                        while (SqlDbLocal.Reader.Read())
                        {
                            var messNum = Convert.ToInt32(SqlDbLocal.Reader["Mess"]);
                            var place = Convert.ToString(SqlDbLocal.Reader["Place"]);
                            DbMess mess = new DbMess(
                            Convert.ToInt32(SqlDbLocal.Reader["IDmess"]),
                            place,
                            Convert.ToDateTime(SqlDbLocal.Reader["DTime"]),
                            Convert.ToString(SqlDbLocal.Reader["DTimeAck"]),
                            Convert.ToInt32(SqlDbLocal.Reader["SysID"]),
                            Convert.ToInt32(SqlDbLocal.Reader["SysNum"]),
                            messNum,
                            Convert.ToString(SqlDbLocal.Reader["Message"]),
                            Convert.ToInt32(SqlDbLocal.Reader["isAck"]),
                            Convert.ToInt32(SqlDbLocal.Reader["Priority"]),
                            Convert.ToString(SqlDbLocal.Reader["Value"])
                            );
                            if (listMess.Count < 20000) listMess.Enqueue(mess);
                        }
                        SqlDbLocal.Reader.Close();
                        LocalOld = LocalNew;
                        Thread.Sleep(100);
                        continue;
                    }
                    if (count < 100) count++;
                    else count = 0;
                    if (count % 4 != 0)
                    {
                        Thread.Sleep(250);
                        continue;
                    }

                    while (listMess.Count > 0)
                    {
                        if (!SqlDbRemote.SqlConnected())
                        {
                            SqlDbRemote = new SqlDb(connectionStringR);
                            SqlDbRemote.Open();
                        }
                        DbMess dmMess = listMess.Peek();
                        SqlDbRemote.CreateDbCommand(
                            "INSERT INTO PLCMessage (IDmess, Place, DTime, dTimeAck, SysID, SysNum, Mess, Message, IsAck, Priority, Value) " +
                            "VALUES (@IDmess, @Place, @DTime, @dTimeAck, @SysID, @SysNum, @Mess, @Message, @IsAck, @Priority ,@Value)");
                        SqlDbRemote.Command.Parameters.Add("@IDmess", SqlDbType.Int).Value = dmMess.IDmess;
                        SqlDbRemote.Command.Parameters.Add("@Place", SqlDbType.NVarChar).Value = dmMess.Place;
                        if (dateTimeFormat)
                        {
                            SqlDbRemote.Command.Parameters.Add("@DTime", SqlDbType.DateTime2).Value = dmMess.DTime;
                        }
                        else
                        {
                            SqlDbRemote.Command.Parameters.Add("@DTime", SqlDbType.NVarChar).Value =
                                dmMess.DTime.ToString(Global.DtimeFormat);
                        }
                        SqlDbRemote.Command.Parameters.Add("@dTimeAck", SqlDbType.NVarChar).Value = dmMess.DTimeAck;
                        SqlDbRemote.Command.Parameters.Add("@SysID", SqlDbType.Int).Value = dmMess.SysID;
                        SqlDbRemote.Command.Parameters.Add("@SysNum", SqlDbType.Int).Value = dmMess.SysNum;
                        SqlDbRemote.Command.Parameters.Add("@Mess", SqlDbType.Int).Value = dmMess.Mess;
                        SqlDbRemote.Command.Parameters.Add("@Message", SqlDbType.NVarChar).Value = dmMess.Message;
                        SqlDbRemote.Command.Parameters.Add("@IsAck", SqlDbType.Int).Value = dmMess.isAck;
                        SqlDbRemote.Command.Parameters.Add("@Priority", SqlDbType.Int).Value = dmMess.Priority;
                        SqlDbRemote.Command.Parameters.Add("@Value", SqlDbType.NVarChar).Value = dmMess.Value;
                        SqlDbRemote.Command.ExecuteNonQuery();
                        listMess.Dequeue();
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка чтения-записи БД ops2- " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }

                Thread.Sleep(250);
            }
        }

        /// <summary>
        /// Пересылка всех сообщений из удаленной базы в локальную
        /// </summary>
        /// <param name="dev"></param>
        private void FromDB(object dev)
        {
            Device d = (Device)dev; //Объект тип устройства
            bool FirstScan = true;
            int RemoteNew = 0;
            int RemoteOld = 0;
            string[] _datasource = d.getProperty(Global.DATASOURCER).Split(new char[] { '|' });
            int i = 0;
            string connectionString = "Data Source=" + d.getProperty(Global.DATASOURCEL) + ";Password=" + Crypt.GetPassword(d.getProperty(Global.PASSWORD)) + ";User ID=" + d.getProperty(Global.USERID) + ";Initial Catalog=" + d.getProperty(Global.INITCATALOGL) + ";Connect Timeout=" + d.getProperty(Global.CONNECTTIMEOUTL);
            var SqlDbLocal = new SqlDb(connectionString);
            string connectionStringR = "";
            var SqlDbRemote = new SqlDb(connectionStringR);
            int _timeout = 1000;
            if (d.getProperty(Global.POLLTIMEOUT) != "") _timeout = Convert.ToInt32(d.getProperty(Global.POLLTIMEOUT));
            #region Ждем соединения с БД

            Thread.Sleep(3000);
            bool firstConnect = false;
            while (!firstConnect)
            {
                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal.Open();
                        SqlDbLocal.GetFieldType();
                        i = 0;
                    }
                    if (i > _datasource.Length - 1) i = 0;
                    connectionStringR = "Data Source=" + _datasource[i] + ";Password=" +
                                               Crypt.GetPassword(d.getProperty(Global.PASSWORDR)) + ";User ID=" +
                                               d.getProperty(Global.USERIDR) + ";Initial Catalog=" +
                                               d.getProperty(Global.INITCATALOGR) + ";Connect Timeout=" +
                                               d.getProperty(Global.CONNECTTIMEOUTR);
                    SqlDbRemote = new SqlDb(connectionStringR);
                    if (!SqlDbRemote.SqlConnected())
                    {
                        SqlDbRemote.Open();
                        SqlDbRemote.GetFieldType();

                    }
                    firstConnect = true;
                    SqlDbLocal.Close();
                    SqlDbRemote.Close();
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка подключения к БД. Попытка подключения через 3 сек... - " + ex.Message);
                    i++;
                    Thread.Sleep(3000);
                }
            }

            #endregion

            if (SqlDbLocal.UseDateTimeInPlcMessage != SqlDbRemote.UseDateTimeInPlcMessage)
            {
                Log.WriteLogToFile(Thread.CurrentThread.Name + " Базы с разными типами. Возможна нестабильная работа блока");
            }
            var dateTimeFormat = SqlDbRemote.UseDateTimeInPlcMessage && SqlDbLocal.UseDateTimeInPlcMessage;
            Queue<DbMess> listMess = new Queue<DbMess>();
            while (true)
            {
               
                #region
                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal = new SqlDb(connectionString);
                        SqlDbLocal.Open();
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }

                try
                {
                    if (!SqlDbRemote.SqlConnected())
                    {
                        if (i > _datasource.Length - 1) i = 0;
                        connectionStringR = "Data Source=" + _datasource[i] + ";Password=" +
                                               Crypt.GetPassword(d.getProperty(Global.PASSWORDR)) + ";User ID=" +
                                               d.getProperty(Global.USERIDR) + ";Initial Catalog=" +
                                               d.getProperty(Global.INITCATALOGR) + ";Connect Timeout=" +
                                               d.getProperty(Global.CONNECTTIMEOUTR);
                        SqlDbRemote = new SqlDb(connectionStringR);
                        SqlDbRemote.Open();
                        FirstScan = true;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка удаленной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    i++;
                    continue;
                }

                #endregion


                #region FirstScan

                if (FirstScan)
                {
                    try
                    {
                        SqlDbRemote.CreateDbCommand("SELECT TOP(1)ID FROM PLCMessage ORDER BY ID DESC");
                        SqlDbRemote.ExecuteReader();
                        while (SqlDbRemote.Reader.Read())
                        {
                            RemoteOld = Convert.ToInt32(SqlDbRemote.Reader["ID"]);
                        }
                        SqlDbRemote.Reader.Close();
                        FirstScan = false;
                    }
                    catch (Exception ex)
                    {
                        Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД на FirstScan - " + ex.Message);
                        Thread.Sleep(1000);
                        continue;
                    }
                }

                #endregion
                try
                {
                    SqlDbRemote.CreateDbCommand("SELECT TOP(1)ID FROM PLCMessage ORDER BY ID DESC");
                    SqlDbRemote.ExecuteReader();
                    while (SqlDbRemote.Reader.Read())
                    {
                        RemoteNew = Convert.ToInt32(SqlDbRemote.Reader["ID"]);
                    }
                    SqlDbRemote.Reader.Close();
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }
                try
                {
                    if (RemoteOld != RemoteNew)
                    {
                        SqlDbRemote.CreateDbCommand("SELECT * FROM PLCMessage WHERE ((ID > @IDOLD) AND (ID <= @IDNEW))");
                        SqlDbRemote.Command.Parameters.Add("@IDOLD", SqlDbType.Int).Value = RemoteOld;
                        SqlDbRemote.Command.Parameters.Add("@IDNEW", SqlDbType.Int).Value = RemoteNew;
                        SqlDbRemote.ExecuteReader();
                        while (SqlDbRemote.Reader.Read())
                        {
                            var messNum = Convert.ToInt32(SqlDbRemote.Reader["Mess"]);
                            var place = Convert.ToString(SqlDbRemote.Reader["Place"]);
                            //if (String.Equals(place, Environment.MachineName, StringComparison.CurrentCultureIgnoreCase) && (messNum < 100 || messNum > 110))
                            //{
                            DbMess mess = new DbMess(
                            Convert.ToInt32(SqlDbRemote.Reader["IDmess"]),
                            place,
                            Convert.ToDateTime(SqlDbRemote.Reader["DTime"]),
                            Convert.ToString(SqlDbRemote.Reader["DTimeAck"]),
                            Convert.ToInt32(SqlDbRemote.Reader["SysID"]),
                            Convert.ToInt32(SqlDbRemote.Reader["SysNum"]),
                            messNum,
                            Convert.ToString(SqlDbRemote.Reader["Message"]),
                            Convert.ToInt32(SqlDbRemote.Reader["isAck"]),
                            Convert.ToInt32(SqlDbRemote.Reader["Priority"]),
                            Convert.ToString(SqlDbRemote.Reader["Value"])
                            );
                            if (listMess.Count < 20000) listMess.Enqueue(mess);
                            //}
                        }
                        SqlDbRemote.Reader.Close();
                        RemoteOld = RemoteNew;
                        Thread.Sleep(100);
                        continue;
                    }

                    while (listMess.Count > 0)
                    {
                        DbMess dmMess = listMess.Peek();
                        SqlDbLocal.CreateDbCommand(
                            "INSERT INTO PLCMessage (IDmess, Place, DTime, dTimeAck, SysID, SysNum, Mess, Message, IsAck, Priority, Value) " +
                            "VALUES (@IDmess, @Place, @DTime, @dTimeAck, @SysID, @SysNum, @Mess, @Message, @IsAck, @Priority ,@Value)");
                        SqlDbLocal.Command.Parameters.Add("@IDmess", SqlDbType.Int).Value = dmMess.IDmess;
                        SqlDbLocal.Command.Parameters.Add("@Place", SqlDbType.NVarChar).Value = dmMess.Place;
                        if (dateTimeFormat)
                        {
                            SqlDbLocal.Command.Parameters.Add("@DTime", SqlDbType.DateTime2).Value = dmMess.DTime;
                        }
                        else
                        {
                            SqlDbLocal.Command.Parameters.Add("@DTime", SqlDbType.NVarChar).Value =
                                dmMess.DTime.ToString(Global.DtimeFormat);
                        }
                        SqlDbLocal.Command.Parameters.Add("@dTimeAck", SqlDbType.NVarChar).Value = dmMess.DTimeAck;
                        SqlDbLocal.Command.Parameters.Add("@SysID", SqlDbType.Int).Value = dmMess.SysID;
                        SqlDbLocal.Command.Parameters.Add("@SysNum", SqlDbType.Int).Value = dmMess.SysNum;
                        SqlDbLocal.Command.Parameters.Add("@Mess", SqlDbType.Int).Value = dmMess.Mess;
                        SqlDbLocal.Command.Parameters.Add("@Message", SqlDbType.NVarChar).Value = dmMess.Message;
                        SqlDbLocal.Command.Parameters.Add("@IsAck", SqlDbType.Int).Value = dmMess.isAck;
                        SqlDbLocal.Command.Parameters.Add("@Priority", SqlDbType.Int).Value = dmMess.Priority;
                        SqlDbLocal.Command.Parameters.Add("@Value", SqlDbType.NVarChar).Value = dmMess.Value;
                        SqlDbLocal.Command.ExecuteNonQuery();
                        listMess.Dequeue();
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка чтения-записи БД ops3 - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }
                Thread.Sleep(_timeout);
            }
        }

private void FromMySQLDB(object dev)
																												 
					  
									  
									   
        {
            Device d = (Device)dev; //Объект тип устройства
            bool FirstScan = true;
            int RemoteNew = 0;
            int RemoteOld = 0;
            string[] _datasource = d.getProperty(Global.DATASOURCER).Split(new char[] { '|' });
            int i = 0;
            string connectionString = "Data Source=" + d.getProperty(Global.DATASOURCEL) + ";Password=" + Crypt.GetPassword(d.getProperty(Global.PASSWORDL)) + ";User ID=" + d.getProperty(Global.USERIDL) + ";Initial Catalog=" + d.getProperty(Global.INITCATALOGL) + ";Connect Timeout=" + d.getProperty(Global.CONNECTTIMEOUTL);
            var SqlDbLocal = new SqlDb(connectionString);
            string connectionStringR = "";
            MySqlDB SqlDbRemote = new MySqlDB(connectionStringR);
            int _timeout = 1000;
            string place = d.getProperty(Global.NAMESYSTEM);
            if (d.getProperty(Global.POLLTIMEOUT) != "") _timeout = Convert.ToInt32(d.getProperty(Global.POLLTIMEOUT));
            #region Ждем соединения с БД

            Thread.Sleep(3000);
            bool firstConnect = false;
            while (!firstConnect)
            {
                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal.Open();
                        SqlDbLocal.GetFieldType();
                        i = 0;
                    }
                    if (i > _datasource.Length - 1) i = 0;
                    connectionStringR = "Server=" + _datasource[i] + ";" +
                                       "Database=" + d.getProperty(Global.INITCATALOGR) + ";" +
                                       "port=3306" + ";" +
                                       "User Id=" + d.getProperty(Global.USERIDR) + ";" +
                                       "password=" + Crypt.GetPassword(d.getProperty(Global.PASSWORDR));
                    SqlDbRemote = new MySqlDB(connectionStringR);
                    if (!SqlDbRemote.SqlConnected())
                    {
                        SqlDbRemote.Open();
                        //SqlDbRemote.GetFieldType();

                    }
                    firstConnect = true;
                    SqlDbLocal.Close();
                    SqlDbRemote.Close();
                }
                catch (Exception exception)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка подключения к БД. Попытка подключения через 3 сек..." + exception.Message);
                    i++;
                    Thread.Sleep(3000);
                }
            }

            #endregion

            //if (SqlDbLocal.UseDateTimeInPlcMessage != SqlDbRemote.UseDateTimeInPlcMessage)
            //{
            //    _oper["log"](Thread.CurrentThread.Name, d.name() + " Базы с разными типами. Возможна нестабильная работа блока");
            //}
            //var dateTimeFormat = SqlDbRemote.UseDateTimeInPlcMessage && SqlDbLocal.UseDateTimeInPlcMessage;
            Queue<DbMess> listMess = new Queue<DbMess>();
            while (true)
            {
               #region

                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal = new SqlDb(connectionString);
                        SqlDbLocal.Open();
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + "Ошибка локальной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }

                try
                {
                    if (!SqlDbRemote.SqlConnected())
                    {
                        if (i > _datasource.Length - 1) i = 0;
                        connectionStringR = "Data Source=" + _datasource[i] + ";Password=" +
                                               Crypt.GetPassword(d.getProperty(Global.PASSWORDR)) + ";User ID=" +
                                               d.getProperty(Global.USERIDR) + ";Initial Catalog=" +
                                               d.getProperty(Global.INITCATALOGR) + ";Connect Timeout=" +
                                               d.getProperty(Global.CONNECTTIMEOUTR);
                        SqlDbRemote = new MySqlDB(connectionStringR);
                        SqlDbRemote.Open();
                        FirstScan = true;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + "Ошибка удаленной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    i++;
                    continue;
                }

                #endregion


                #region FirstScan

                if (FirstScan)
                {
                    try
                    {
                        SqlDbRemote.CreateDbCommand("SELECT idx FROM TnCuAlarms_archive ORDER BY idx DESC limit 1");
                        SqlDbRemote.ExecuteDBReader();
                        while (SqlDbRemote.Reader.Read())
                        {
                            RemoteOld = Convert.ToInt32(SqlDbRemote.Reader["idx"]);
                        }
                        SqlDbRemote.Reader.Close();
                        FirstScan = false;
                    }
                    catch (Exception ex)
                    {
                        Log.WriteLogToFile(Thread.CurrentThread.Name + "Ошибка удаленной БД на FirstScan - " + ex.Message);
                        Thread.Sleep(1000);
                        continue;
                    }
                }

                #endregion
                try
                {
                    SqlDbRemote.CreateDbCommand("SELECT idx FROM TnCuAlarms_archive ORDER BY idx DESC limit 1");
                    SqlDbRemote.ExecuteDBReader();
                    while (SqlDbRemote.Reader.Read())
                    {
                        RemoteNew = Convert.ToInt32(SqlDbRemote.Reader["idx"]);
                    }
                    SqlDbRemote.Reader.Close();
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + "Ошибка удаленной БД - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }
                try
                {
                    if (RemoteOld != RemoteNew)
                    {
                        SqlDbRemote.CreateDbCommand("SELECT * FROM TnCuAlarms_archive WHERE ((idx > @IDOLD) AND (idx <= @IDNEW))");
                        SqlDbRemote.Command.Parameters.AddWithValue("@IDOLD", SqlDbType.Int).Value = RemoteOld;
                        SqlDbRemote.Command.Parameters.AddWithValue("@IDNEW", SqlDbType.Int).Value = RemoteNew;
                        SqlDbRemote.ExecuteDBReader();
                        while (SqlDbRemote.Reader.Read())
                        {
                            var idx = Convert.ToInt32(SqlDbRemote.Reader["idx"]);
                            var date = Convert.ToDateTime(SqlDbRemote.Reader["date"]);
                            var time = Convert.ToDateTime(SqlDbRemote.Reader["time"]);
                            var sysid = SqlDbRemote.Reader["sysid"] is DBNull ? 201 : (Convert.ToInt32(SqlDbRemote.Reader["sysid"]));
                            var messnum = SqlDbRemote.Reader["mess"] is DBNull ? 201 : (Convert.ToInt32(SqlDbRemote.Reader["mess"]));
                            var sysnum = SqlDbRemote.Reader["sysnum"] is DBNull ? 201 : (Convert.ToInt32(SqlDbRemote.Reader["sysnum"]));
                            var text = Convert.ToString(SqlDbRemote.Reader["text"]);
                            var priority = Convert.ToInt32(SqlDbRemote.Reader["priority"]); //+ 1;
                            var datetime = new DateTime(date.Year, date.Month, date.Day, time.Hour, time.Minute, time.Second);
                            
                            //if (String.Equals(place, Environment.MachineName, StringComparison.CurrentCultureIgnoreCase) && (messNum < 100 || messNum > 110))
                            //{
                            DbMess mess = new DbMess(
                            idx,
                            place,         //place
                            datetime,
                            "",         //ack
                            sysid,          //sysID
                            sysnum,          //sysNum
                            messnum,          //messNum
                            text,
                            0,          //isack
                            priority,
                            ""          //value
                            );
                            if (listMess.Count < 20000) listMess.Enqueue(mess);
                            //}
                        }
                        SqlDbRemote.Reader.Close();
                        RemoteOld = RemoteNew;
                        Thread.Sleep(100);
                        continue;
                    }

                    while (listMess.Count > 0)
                    {
                        DbMess dmMess = listMess.Peek();
                        SqlDbLocal.CreateDbCommand(
                            "INSERT INTO PLCMessage (IDmess, Place, DTime, dTimeAck, SysID, SysNum, Mess, Message, IsAck, Priority, Value) " +
                            "VALUES (@IDmess, @Place, @DTime, @dTimeAck, @SysID, @SysNum, @Mess, @Message, @IsAck, @Priority ,@Value)");
                        SqlDbLocal.Command.Parameters.Add("@IDmess", SqlDbType.Int).Value = dmMess.IDmess;
                        SqlDbLocal.Command.Parameters.Add("@Place", SqlDbType.NVarChar).Value = dmMess.Place;
                        //if (dateTimeFormat)
                        //{
                            SqlDbLocal.Command.Parameters.Add("@DTime", SqlDbType.DateTime2).Value = dmMess.DTime;
                        //}
                        //else
                        //{
                        //    SqlDbLocal.Command.Parameters.Add("@DTime", SqlDbType.NVarChar).Value =
                        //        dmMess.DTime.ToString(Global.DtimeFormat);
                        //}
                        SqlDbLocal.Command.Parameters.Add("@dTimeAck", SqlDbType.NVarChar).Value = dmMess.DTimeAck;
                        SqlDbLocal.Command.Parameters.Add("@SysID", SqlDbType.Int).Value = dmMess.SysID;
                        SqlDbLocal.Command.Parameters.Add("@SysNum", SqlDbType.Int).Value = dmMess.SysNum;
                        SqlDbLocal.Command.Parameters.Add("@Mess", SqlDbType.Int).Value = dmMess.Mess;
                        SqlDbLocal.Command.Parameters.Add("@Message", SqlDbType.NVarChar).Value = dmMess.Message;
                        SqlDbLocal.Command.Parameters.Add("@IsAck", SqlDbType.Int).Value = dmMess.isAck;
                        SqlDbLocal.Command.Parameters.Add("@Priority", SqlDbType.Int).Value = dmMess.Priority;
                        SqlDbLocal.Command.Parameters.Add("@Value", SqlDbType.NVarChar).Value = dmMess.Value;
                        SqlDbLocal.Command.ExecuteNonQuery();
                        listMess.Dequeue();
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + "Ошибка чтения-записи БД ops4 - " + ex.Message);
                    Thread.Sleep(1000);
                    continue;
                }
                Thread.Sleep(_timeout);
            }
        }
        /// <summary>
        /// Пинг
        /// </summary>
        /// <param name="dev"></param>
        private void DIAG(object dev)
        {
            Device d = (Device)dev;
            UFunction WriteToPLC = new UFunction();
            string IP1 = d.getProperty(Global.IP1);
            string IP2 = d.getProperty(Global.IP2);
            Int32 Adress1 = Convert.ToInt32(d.getProperty(Global.ADRESS1));
            Int32 Adress2 = Convert.ToInt32(d.getProperty(Global.ADRESS2));
            Ping ping = new Ping();
            bool ConnectIp1 = false;
            bool ConnectIp2 = false;
            while (true)
            {
                try
                {
                    var PingReply = ping.Send(IP1, 1000);
                    if (PingReply != null && PingReply.Status != IPStatus.Success)
                    {
                        if (ConnectIp1) ConnectIp1 = !WriteToPLC.WtiteValue(Adress1, 0);
                    }
                    else
                    {
                        if (!ConnectIp1) ConnectIp1 = WriteToPLC.WtiteValue(Adress1, 1);
                    }
                    PingReply = ping.Send(IP2, 1000);
                    if (PingReply != null && PingReply.Status != IPStatus.Success)
                    {
                        if (ConnectIp2) ConnectIp2 = !WriteToPLC.WtiteValue(Adress2, 0);
                    }
                    else
                    {
                        if (!ConnectIp2) ConnectIp2 = WriteToPLC.WtiteValue(Adress2, 1);
                    }
                    Thread.Sleep(1000);
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка - " + ex.Message);
                    Thread.Sleep(3000);
                }
            }
        }

        /// <summary>
        /// Квитирование
        /// </summary>
        /// <param name="dev"></param>
        private void Ack(object dev)
        {
            Device d = (Device)dev; //Объект тип устройства
            bool FirstScan = true;
            int LocalNew = 0;
            int LocalOld = 0;
            int IDNew = 0;
            int IDOld = 0;
            SqlDb.FieldType fieldType = SqlDb.FieldType.Varchar;
            //string connectionString = "Provider=" + d.getProperty(Global.PROVIDERL) + ";Data Source=" + d.getProperty(Global.DATASOURCEL) + ";Password=" + Crypt.GetPassword(d.getProperty(Global.PASSWORDL)) + ";User ID=" + d.getProperty(Global.USERIDL) + ";Initial Catalog=" + d.getProperty(Global.INITCATALOGL) + ";Connect Timeout=" + d.getProperty(Global.CONNECTTIMEOUTL);
            string connectionString = "Data Source=" + d.getProperty(Global.DATASOURCEL) + ";Password=" + Crypt.GetPassword(d.getProperty(Global.PASSWORDL)) + ";User ID=" + d.getProperty(Global.USERIDL) + ";Initial Catalog=" + d.getProperty(Global.INITCATALOGL) + ";Connect Timeout=" + d.getProperty(Global.CONNECTTIMEOUTL);
            var SqlDbLocal = new SqlDb(connectionString);
            var SqlDbLocalAckAll = new SqlDb(connectionString);
            while (true)
            {
                try
                {
                    if (!SqlDbLocal.SqlConnected())
                    {
                        SqlDbLocal = new SqlDb(connectionString);
                        SqlDbLocal.Open();
                        fieldType = SqlDbLocal.GetFieldType();
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД - " + ex.Message);
                    Thread.Sleep(3000);
                    continue;
                }

                if (FirstScan)
                {
                    try
                    {
                        SqlDbLocal.CreateDbCommand("SELECT TOP(1)ID FROM PLCMessage ORDER BY ID DESC");
                        SqlDbLocal.ExecuteReader();
                        while (SqlDbLocal.Reader.Read())
                        {
                            LocalOld = Convert.ToInt32(SqlDbLocal.Reader["ID"]);
                        }
                        SqlDbLocal.Reader.Close();
                        FirstScan = false;
                    }
                    catch (Exception ex)
                    {
                        Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД на FirsScan - " + ex.Message);
                        continue;
                    }
                }
                try
                {
                    SqlDbLocal.CreateDbCommand("SELECT TOP(1)ID FROM PLCMessage ORDER BY ID DESC");
                    SqlDbLocal.ExecuteReader();
                    while (SqlDbLocal.Reader.Read())
                    {
                        LocalNew = Convert.ToInt32(SqlDbLocal.Reader["ID"]);
                    }
                    SqlDbLocal.Reader.Close();
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД - " + ex.Message);
                    continue;
                }
                try
                {
                    if (LocalOld != LocalNew)
                    {
                        SqlDbLocal.CreateDbCommand("SELECT * FROM PLCMessage WHERE ((ID > @IDOLDm) AND (ID <= @IDNEWm))");
                        SqlDbLocal.Command.Parameters.Add("@IDOLDm", SqlDbType.Decimal).Value = LocalOld;
                        SqlDbLocal.Command.Parameters.Add("@IDNEWm", SqlDbType.Decimal).Value = LocalNew;
                        SqlDbLocal.ExecuteReader();
                        while (SqlDbLocal.Reader.Read())
                        {
                            if (Convert.ToString(SqlDbLocal.Reader["SysID"]) != Global.ARM || Convert.ToString(SqlDbLocal.Reader["SysNum"]) != "1") continue;
                            var buf = Convert.ToString(SqlDbLocal.Reader["Value"]).Split(';');
                            if (Convert.ToString(SqlDbLocal.Reader["Mess"]) == Global.ACKONCE && buf.Length == 4)
                            {
                                SqlDbLocalAckAll = new SqlDb(connectionString);
                                SqlDbLocalAckAll.Open();
                                SqlDbLocalAckAll.CreateDbCommand("UPDATE PLCMessage SET DTimeAck = @DTimeAck  WHERE (DTime = @DTime) AND (SysId = @SysId) AND (SysNum = @SysNum) AND (Mess = @Mess)");
                                switch (fieldType)
                                {
                                    case SqlDb.FieldType.Datetime2:
                                        DateTime timeAck = Convert.ToDateTime(SqlDbLocal.Reader["DTime"]);
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value = timeAck.ToString(Global.DtimeFormat);
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTime", SqlDbType.DateTime2).Value = Convert.ToDateTime(buf[3]);
                                        break;
                                    case SqlDb.FieldType.Datetime:
                                        timeAck = Convert.ToDateTime(SqlDbLocal.Reader["DTime"]);
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value = timeAck.ToString(Global.DtimeFormat);
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTime", SqlDbType.DateTime).Value = Convert.ToDateTime(buf[3]);
                                        break;
                                    default:
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value = Convert.ToString(SqlDbLocal.Reader["DTime"]);
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTime", SqlDbType.VarChar).Value = buf[3];
                                        break;
                                }
                                SqlDbLocalAckAll.Command.Parameters.Add("@SysId", SqlDbType.Int).Value = Convert.ToInt32(buf[0]);
                                SqlDbLocalAckAll.Command.Parameters.Add("@SysNum", SqlDbType.Int).Value = Convert.ToInt32(buf[1]);
                                SqlDbLocalAckAll.Command.Parameters.Add("@Mess", SqlDbType.Int).Value = Convert.ToInt32(buf[2]);
                                SqlDbLocalAckAll.Command.ExecuteNonQuery();
                                SqlDbLocalAckAll.Close();
                            }

                            #region Квитирование всех

                            if (Convert.ToString(SqlDbLocal.Reader["Mess"]) == Global.ACKALL && buf.Length >= 8)
                            {
                                SqlDbLocalAckAll = new SqlDb(connectionString);
                                SqlDbLocalAckAll.Open();
                                SqlDbLocalAckAll.CreateDbCommand(
                                    "SELECT TOP(1)ID FROM PLCMessage WHERE (DTime = @DTime) AND (SysId = @SysId) AND (SysNum = @SysNum) AND (Mess = @Mess) ORDER BY ID DESC");
                                switch (fieldType)
                                {
                                    case SqlDb.FieldType.Datetime2:
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTime", SqlDbType.DateTime2).Value =
                                            Convert.ToDateTime(buf[3]);
                                        break;
                                    case SqlDb.FieldType.Datetime:
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTime", SqlDbType.DateTime).Value =
                                            Convert.ToDateTime(buf[3]);
                                        break;
                                    default:
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTime", SqlDbType.VarChar).Value =
                                            buf[3];
                                        break;
                                }
                                SqlDbLocalAckAll.Command.Parameters.Add("@SysId", SqlDbType.Int).Value =
                                    Convert.ToInt32(buf[0]);
                                SqlDbLocalAckAll.Command.Parameters.Add("@SysNum", SqlDbType.Int).Value =
                                    Convert.ToInt32(buf[1]);
                                SqlDbLocalAckAll.Command.Parameters.Add("@Mess", SqlDbType.Int).Value =
                                    Convert.ToInt32(buf[2]);
                                SqlDbLocalAckAll.ExecuteReader();
                                while (SqlDbLocalAckAll.Reader.Read())
                                {
                                    IDNew = Convert.ToInt32(SqlDbLocalAckAll.Reader["ID"]);
                                }
                                SqlDbLocalAckAll.Reader.Close();

                                SqlDbLocalAckAll.CreateDbCommand(
                                    "SELECT TOP(1)ID FROM PLCMessage WHERE (DTime = @DTime) AND (SysId = @SysId) AND (SysNum = @SysNum) AND (Mess = @Mess) ORDER BY ID DESC");
                                switch (fieldType)
                                {
                                    case SqlDb.FieldType.Datetime2:
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTime", SqlDbType.DateTime2).Value =
                                            Convert.ToDateTime(buf[7]);
                                        break;
                                    case SqlDb.FieldType.Datetime:
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTime", SqlDbType.DateTime).Value =
                                            Convert.ToDateTime(buf[7]);
                                        break;
                                    default:
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTime", SqlDbType.VarChar).Value =
                                            buf[7];
                                        break;
                                }
                                SqlDbLocalAckAll.Command.Parameters.Add("@SysId", SqlDbType.Int).Value =
                                    Convert.ToInt32(buf[4]);
                                SqlDbLocalAckAll.Command.Parameters.Add("@SysNum", SqlDbType.Int).Value =
                                    Convert.ToInt32(buf[5]);
                                SqlDbLocalAckAll.Command.Parameters.Add("@Mess", SqlDbType.Int).Value =
                                    Convert.ToInt32(buf[6]);
                                SqlDbLocalAckAll.ExecuteReader();
                                while (SqlDbLocalAckAll.Reader.Read())
                                {
                                    IDOld = Convert.ToInt32(SqlDbLocalAckAll.Reader["ID"]);
                                }
                                SqlDbLocalAckAll.Reader.Close();

                                if (IDNew > IDOld)
                                {
                                    SqlDbLocalAckAll.CreateDbCommand(
                                        "UPDATE PLCMessage SET DTimeAck = @DTimeAck WHERE (ID >= @IDOld) AND (ID <= @IDNew) AND (isAck = @isAck)");
                                }
                                else
                                {
                                    SqlDbLocalAckAll.CreateDbCommand(
                                        "UPDATE PLCMessage SET DTimeAck = @DTimeAck WHERE (ID <= @IDOld) AND (ID >= @IDNew) AND (isAck = @isAck)");
                                }
                                switch (fieldType)
                                {
                                    case SqlDb.FieldType.Datetime2:
                                        DateTime timeAck = Convert.ToDateTime(SqlDbLocal.Reader["DTime"]);
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value =
                                            timeAck.ToString(Global.DtimeFormat);
                                        break;
                                    case SqlDb.FieldType.Datetime:
                                        timeAck = Convert.ToDateTime(SqlDbLocal.Reader["DTime"]);
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value =
                                            timeAck.ToString(Global.DtimeFormat);
                                        break;
                                    default:
                                        SqlDbLocalAckAll.Command.Parameters.Add("@DTimeAck", SqlDbType.VarChar).Value =
                                            Convert.ToString(SqlDbLocal.Reader["DTime"]);
                                        break;
                                }
                                SqlDbLocalAckAll.Command.Parameters.Add("@IDOld", SqlDbType.Int).Value = IDOld;
                                SqlDbLocalAckAll.Command.Parameters.Add("@IDNew", SqlDbType.Int).Value = IDNew;
                                SqlDbLocalAckAll.Command.Parameters.Add("@isAck", SqlDbType.Int).Value =
                                    Convert.ToInt32(Global.ISACK);
                                SqlDbLocalAckAll.Command.ExecuteNonQuery();
                                SqlDbLocalAckAll.Close();
                            }

                            #endregion
                        }
                        SqlDbLocal.Reader.Close();
                    }
                    LocalOld = LocalNew;
                }
                catch (Exception ex)
                {
                    Log.WriteLogToFile(Thread.CurrentThread.Name + " Ошибка локальной БД - " + ex.Message);
                    continue;
                }
                Thread.Sleep(1000);
            }
        }
    }
    public class DbMess
    {
        public int IDmess;
        public string Place;
        public DateTime DTime;
        public string DTimeAck;
        public int SysID;
        public int SysNum;
        public int Mess;
        public string Message;
        public int isAck;
        public int Priority;
        public string Value;

        public DbMess(int dmess, string place, DateTime dTime, string dTimeAck, int sysId, int sysNum, int mess, string message, int isAck, int priority, string value)
        {
            IDmess = dmess;
            Place = place;
            DTime = dTime;
            DTimeAck = dTimeAck;
            SysID = sysId;
            SysNum = sysNum;
            Mess = mess;
            Message = message;
            this.isAck = isAck;
            Priority = priority;
            Value = value;
        }
    }
}