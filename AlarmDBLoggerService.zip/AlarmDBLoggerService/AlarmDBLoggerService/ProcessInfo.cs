﻿using System;

namespace AlarmDBLoggerService
{
    public class ProcessInfo
    {
        public ProcessInfo(string processName)
        {
            Name = processName;
        }

        public string Name { get; internal set; }

        public int? Cpu { get; internal set; }

        public int? Ram { get; internal set; }

        public DateTime? StartTime { get; internal set; }

        public int InstanceCount { get; internal set; }
    }
}
