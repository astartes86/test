﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text.RegularExpressions;

namespace AlarmDBLoggerService
{
    public class Device
    {
        private string dName;
        private Dictionary<string, string> avMap = new Dictionary<string, string>();

        public Device()
        {
        }

        public Device(string devName)
        {
            dName = devName;
        }

        public string name()
        {
            return dName;
        }

        public void Validate(List<string> vals, List<string> rxs)
        {
            int excess = 0;
            int missing = 0;
            int i = 0;
            Regex[] rgxAv = new Regex[rxs.Count];

            foreach (string s in avMap.Keys)
            {
                if (!vals.Contains(s)) missing++;
                if (missing != 0) Log.WriteLogToFile("Отсутствует настройка " + s + " объекта " + name());
            }

            foreach (string s in vals)
            {
                if (!avMap.ContainsKey(s)) excess++;
                if (excess != 0) Log.WriteLogToFile("Отсутствует значение настройки" + s + " объекта " + name());
            }

            foreach (string s in rxs)
            {
                rgxAv[i] = new Regex(s);
                i++;
            }

        }

        public void setProperty(string attr, string val)
        {
            if (avMap.ContainsKey(attr))
            {
                Log.WriteLogToFile("Duplicate configuration entry " + attr + " for device " + val);
            }
            else
            {
                avMap[attr] = val;
            }
        }

        public string getProperty(string propName)
        {
            if (avMap.ContainsKey(propName))
            {
                return avMap[propName];
            }
            else
            {
                return "";
            }

        }
      
    }
}
