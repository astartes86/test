﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.ServiceProcess;
using System.Text.RegularExpressions;
using System.Threading;
using System.Timers;
//using static AlarmDBLoggerService.Constants;
using Timer = System.Timers.Timer;

namespace AlarmDBLoggerService
{
    public partial class AlarmDBLoggerService : ServiceBase
    {
        Threads _myThreads;
        List<Device> devices;
        List<string> names;

        public AlarmDBLoggerService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            var thread = new Thread(WrapperLog) //создаем поток
            {
                Name = "WrapperLog",
                IsBackground = true
            };
            thread.Start(); // запускаем наш поток и передаем в него объект
            StartAll();
        }

        private void WrapperLog()
        {
            try
            {
                while (true)
                {
                    if (QueueManager.QueueLog.Count > 0)
                    {
                        LogMessage message = QueueManager.QueueLog.Dequeue();
                        if (message == null) continue;
                        Log.WriteLogToFile(message);
                    }
                    else
                    {
                        Thread.Sleep(500);
                    }
                }
            }
            catch
            {
                //
            }
        }

        protected override void OnStop()
        {
            Log.WriteLogToFile(new LogMessage("Служба AlarmDBLogger остановлена", DateTime.Now));
            //Log.WriteLogToFile("Служба PcDiag остановлена");
            Log.StopLog = true;
            _myThreads?.Abort();
            Dispose(true);
        }

        private void StartAll()
        {
            try
            {
                Log.WriteLogToFile("Служба AlarmDBLogger запущена");
                string devName;
                Device dev = null;
                devices = new List<Device>();
                names = new List<string>();
                string pathFile = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "\\thread.cfg";//Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location + "\\PcDiag.ini");
                if (!File.Exists(pathFile)) Log.WriteLogToFile("Конфигурационный файл не найден" + pathFile);
                string s = File.ReadAllText(pathFile);             
                if (string.IsNullOrEmpty(s)) Log.WriteLogToFile("Конфигурационный файл - пустой" + pathFile);
                Regex rgxAV = new Regex("^(\\w+)=(.+)$");
                Regex rgxDevice = new Regex("^\\[(.+)\\]$");
                s = Regex.Replace(s, "[ \\t]", "");
                s = Regex.Replace(s, ";.*[\r\n]+", "");
                s = Regex.Replace(s, "[\r\n]+$", "");
                s = Regex.Replace(s, "[\r\n]+", " ");



                string[] _s = s.Split(null);

                foreach (string stroka in _s)
                {
                    if (rgxDevice.Match(stroka).Success)
                    {
                        devName = Convert.ToString(rgxDevice.Match(stroka).Groups[1]);
                        if (names.Contains(devName))
                        {
                            Log.WriteLogToFile("Дублирование объекта " + devName + " в конфигурационном файле");
                        }
                        if (dev == null)
                        {
                            dev = new Device(devName);
                        }
                        else
                        {
                            devices.Add(dev);
                            dev = new Device(devName);
                        }
                        names.Add(devName);
                    }
                    else if (rgxAV.Match(stroka).Success)
                    {
                        if (dev == null)
                        {
                            Log.WriteLogToFile("Configuration entry " + stroka + " not associated w/device");
                        }
                        else
                        {
                            dev.setProperty(Convert.ToString(rgxAV.Match(stroka).Groups[1]).ToLower(), Convert.ToString(rgxAV.Match(stroka).Groups[2]));//Убрал приведение к ToLower т.к. бывает важно в каком рег имена БД
                        }
                    }
                    else
                    {
                        Log.WriteLogToFile("Invalid entry " + stroka + " in configuration");
                    }
                }
                if (dev != null)
                {
                    devices.Add(dev);
                }

                if (devices.Count == 0)
                {
                    Log.WriteLogToFile("Configuration file contains no valid data");
                }
                else
                {
                    foreach (Device d in devices)
                    {
                        Device device = d;
                        string type = device.getProperty(Global.TYPE);

                        if (type == "")
                        {
                            Log.WriteLogToFile("Device " + device.name() + " type not specified");
                        }
                        else if (type == Global.PLC)
                        {
                            List<string> vals = new List<string>();
                            List<string> rxs = new List<string>();
                            vals.Add(Global.TYPE); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.HOST); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PORT); rxs.Add("[\\d{1,5}]+");
                            vals.Add(Global.PROVIDERL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.DATASOURCEL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.USERIDL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PASSWORDL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.INITCATALOGL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.CONNECTTIMEOUTL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.SHIFT); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.SYSTEM); rxs.Add("[\\d{1,2}]+");
                            vals.Add(Global.PLCTYPE); rxs.Add(Global.PlcTypeQuantum + "|" + Global.PlcTypeM340 + "|" + Global.PlcTypeM580);
                            vals.Add(Global.ButtTableName); rxs.Add("[\\w\\d\\.]+");
                            device.Validate(vals, rxs);
                        }
                        else if (type == Global.DB)
                        {
                            List<string> vals = new List<string>();
                            List<string> rxs = new List<string>();
                            vals.Add(Global.TYPE); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PROVIDERL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.DATASOURCEL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.USERIDL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PASSWORDL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.INITCATALOGL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.CONNECTTIMEOUTL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PROVIDERR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.DATASOURCER); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.USERIDR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PASSWORDR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.INITCATALOGR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.CONNECTTIMEOUTR); rxs.Add("[\\w\\d\\.]+");
                            device.Validate(vals, rxs);
                        }
                        else if (type == Global.DIAG)
                        {
                            List<string> vals = new List<string>();
                            List<string> rxs = new List<string>();
                            vals.Add(Global.TYPE); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.IP1); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.ADRESS1); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.IP2); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.ADRESS2); rxs.Add("[\\w\\d\\.]+");
                            device.Validate(vals, rxs);
                        }
                        else if (type == Global.ACK)
                        {
                            List<string> vals = new List<string>();
                            List<string> rxs = new List<string>();
                            vals.Add(Global.TYPE); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PROVIDERL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.DATASOURCEL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.USERIDL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PASSWORDL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.INITCATALOGL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.CONNECTTIMEOUTL); rxs.Add("[\\w\\d\\.]+");
                            device.Validate(vals, rxs);
                        }
                        else if (type == Global.DBcopy)
                        {
                            List<string> vals = new List<string>();
                            List<string> rxs = new List<string>();
                            vals.Add(Global.TYPE); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PROVIDERL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.DATASOURCEL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.USERIDL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PASSWORDL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.INITCATALOGL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.CONNECTTIMEOUTL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PROVIDERR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.DATASOURCER); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.USERIDR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PASSWORDR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.INITCATALOGR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.CONNECTTIMEOUTR); rxs.Add("[\\w\\d\\.]+");
                            device.Validate(vals, rxs);
                        }
                        else if (type == Global.FromDB)
                        {
                            List<string> vals = new List<string>();
                            List<string> rxs = new List<string>();
                            vals.Add(Global.TYPE); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PROVIDERL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.DATASOURCEL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.INITCATALOGL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.CONNECTTIMEOUTL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PROVIDERR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.DATASOURCER); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.INITCATALOGR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.CONNECTTIMEOUTR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.USERID); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PASSWORD); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.POLLTIMEOUT); rxs.Add("[\\w\\d\\.]+");
                            device.Validate(vals, rxs);
                        }
                        else if (type == Global.FromMySQLDB)
                        {
                            List<string> vals = new List<string>();
                            List<string> rxs = new List<string>();
                            vals.Add(Global.TYPE); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PROVIDERL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.DATASOURCEL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.USERIDL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PASSWORDL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.INITCATALOGL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.CONNECTTIMEOUTL); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PROVIDERR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.DATASOURCER); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.INITCATALOGR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.CONNECTTIMEOUTR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.USERIDR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.PASSWORDR); rxs.Add("[\\w\\d\\.]+");
                            vals.Add(Global.POLLTIMEOUT); rxs.Add("[\\w\\d\\.]+");
                            device.Validate(vals, rxs);
                        }
                    }
                }
                Log.WriteLogToFile("Служба начала работу c настройками - " + pathFile + " Всего потоков: " + devices.Count);
                _myThreads = new Threads(); //передаем указатель на методы обновления GUI
                _myThreads.Run(names, devices);
            }
            catch (Exception error)
            {
                Log.WriteLogToFile(error);
            }
        }

        private void _starTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            _myThreads = new Threads(); //передаем указатель на методы обновления GUI
            _myThreads.Run(names, devices);
        }
    }
}
